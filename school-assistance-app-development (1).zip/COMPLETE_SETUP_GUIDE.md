# 📚 School Helper - Complete Setup & Usage Guide

Welcome to School Helper! This guide covers everything you need to get started and use all features.

## Table of Contents
1. [Quick Start](#quick-start)
2. [Complete Setup](#complete-setup)
3. [Features Overview](#features-overview)
4. [Using Each Feature](#using-each-feature)
5. [Google Classroom Integration](#google-classroom-integration)
6. [Homework Helper](#homework-helper)
7. [Tips & Best Practices](#tips--best-practices)
8. [Troubleshooting](#troubleshooting)

## Quick Start

### 1-Minute Setup (Without Google Classroom)

```bash
# 1. Install dependencies
npm install

# 2. Set up database
npx drizzle-kit push

# 3. Start development server
npm run dev

# 4. Open http://localhost:3000
# 5. Click "Use as guest" to start immediately
```

Done! You can now use all core features without signing in.

### 3-Minute Setup (Full Features)

If you want Google Classroom + Homework Helper:

```bash
# 1. Set up environment variables
cp .env.example .env.local
# Edit .env.local with your credentials

# 2. Install and setup
npm install
npx drizzle-kit push

# 3. Start server
npm run dev

# 4. Click "Sign in with Google"
# 5. Click "🔗 Sync Now" to import courses
# 6. Click "🤖 Helper" to ask homework questions
```

## Complete Setup

### Prerequisites
- Node.js 18+
- PostgreSQL database
- Google account (optional, for Classroom integration)
- Anthropic account (optional, for Homework Helper)

### Step 1: Environment Variables

Create `.env.local` in project root:

```env
# Required
DATABASE_URL=postgresql://user:password@localhost:5432/app_db

# Google Classroom (optional)
GOOGLE_CLIENT_ID=your_id
GOOGLE_CLIENT_SECRET=your_secret

# Homework Helper (optional)
ANTHROPIC_API_KEY=your_api_key

# NextAuth
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your_secret
```

### Step 2: Install Dependencies

```bash
npm install
```

### Step 3: Database Setup

```bash
# Create tables
npx drizzle-kit push

# Or see database for existing setup
npx drizzle-kit studio
```

### Step 4: Run Development Server

```bash
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000)

### Step 5: (Optional) Google Classroom Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create new project
3. Enable "Google Classroom API"
4. Create OAuth 2.0 credentials (Web application)
5. Add `http://localhost:3000/api/auth/callback/google` to redirect URIs
6. Copy Client ID and Secret to `.env.local`
7. Restart dev server
8. Sign in with Google

Details: See [GOOGLE_CLASSROOM_SETUP.md](./GOOGLE_CLASSROOM_SETUP.md)

### Step 6: (Optional) Homework Helper Setup

1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Create account
3. Generate API key
4. Add `ANTHROPIC_API_KEY=your_key` to `.env.local`
5. Restart dev server
6. Click "🤖 Helper" to start

Details: See [HOMEWORK_HELPER_GUIDE.md](./HOMEWORK_HELPER_GUIDE.md)

## Features Overview

### 🏠 Dashboard
- View academic overview
- Quick statistics (subjects, assignments, grades)
- Upcoming assignments timeline
- Quick action buttons to all features
- Google Classroom sync button (if set up)

### 📖 Subjects
- Add, edit, delete courses
- Track teacher names and classrooms
- View assignments per subject
- View grades per subject
- Import from Google Classroom (if set up)

### ✅ Assignments
- Create and manage assignments
- Set due dates and priorities (Low/Medium/High)
- Mark as complete
- Filter by status (Pending/Completed/Overdue)
- Visual indicators for urgency
- Auto-import from Google Classroom (if set up)

### 📊 Grades
- Record grades with scores
- Automatic percentage calculation
- GPA calculation
- Subject-specific averages
- Grade statistics and analytics
- Filter and organize by subject

### 📝 Notes
- Create study notes with rich text
- Mark important notes with ⭐
- Organize by subject
- Easy editing and deletion
- Important notes highlighted

### 📅 Schedule
- Add classes, exams, labs, events
- Set specific times and locations
- Group by date
- Type indicators with emojis
- Filter and sort

### 🤖 Homework Helper
- Ask homework questions
- Get AI-powered explanations
- Link to your subjects
- Save important responses
- View complete history
- Beautiful formatted responses

## Using Each Feature

### Dashboard

**What to do:**
1. Open app → Dashboard is default page
2. View stats and quick links
3. See upcoming assignments
4. Click quick action buttons

**Tips:**
- Check pending assignments daily
- Use dashboard as your main hub
- Click subjects to see details

### Subjects

**Add a Subject:**
1. Click "Subjects" in navigation
2. Click "➕ Add Subject"
3. Fill in course details:
   - Subject Name (required)
   - Course Code (required)
   - Teacher Name
   - Classroom Location
4. Click "Create Subject"

**Edit/Delete:**
- Click ✏️ to edit
- Click 🗑️ to delete

### Assignments

**Create Assignment:**
1. Click "Assignments"
2. Click "➕ New Assignment"
3. Select subject (required)
4. Set priority (Low/Medium/High)
5. Enter title and description
6. Set due date
7. Click "Create Assignment"

**Manage:**
- Mark ✓ done when completed
- ✏️ Edit anytime
- 🗑️ Delete if not needed
- Filter by status in toolbar

### Grades

**Add Grade:**
1. Click "Grades"
2. Click "➕ New Grade"
3. Select subject (required)
4. Enter assessment title
5. Enter score and max score
6. Set grade date
7. Add notes (optional)
8. Click "Record Grade"

**View Analytics:**
- See overall average at top
- View subject-specific averages
- Click subject filter to drill down
- Review grade trends

### Notes

**Create Note:**
1. Click "Notes"
2. Click "📝 New Note"
3. Select subject
4. Enter title
5. Write content (supports markdown)
6. Check "⭐ Mark as Important" if needed
7. Click "Create Note"

**Tips:**
- Use for important concepts
- Mark key topics with ⭐
- Markdown formatting works (bold, lists, etc.)
- Search by clicking a subject

### Schedule

**Add Event:**
1. Click "Schedule"
2. Click "📅 Add Event"
3. Select subject (required)
4. Choose type (Class/Exam/Lab/Other)
5. Enter title
6. Set date and times
7. Add location and notes
8. Click "Add Event"

**View:**
- Events grouped by date
- Sorted chronologically
- Click 🗑️ to remove
- Click ✏️ to edit

### Homework Helper

**Ask Question:**
1. Click "🤖 Helper" in navigation
2. Click "❓ Ask a Question" tab
3. Select subject (optional)
4. Enter topic title
5. Write detailed question
6. Click "✨ Get Help"
7. Review AI response
8. Click "☆ Save" if helpful

**View History:**
1. Click "📚 History" tab
2. See all past questions
3. Filter by "⭐ Saved" if wanted
4. Click any item to view again
5. Click 🗑️ to delete

**Tips:**
- Be specific in questions
- Include context you've tried
- Ask about concepts, not answers
- Save important explanations

## Google Classroom Integration

### Setup
See [GOOGLE_CLASSROOM_SETUP.md](./GOOGLE_CLASSROOM_SETUP.md) for detailed instructions.

**Quick setup:**
1. Sign in with Google
2. Grant permissions
3. Click "🔗 Sync Now" on dashboard
4. Wait for sync to complete
5. Your courses appear as subjects
6. Assignments are imported

### What Gets Synced
- ✅ All your courses → Subjects
- ✅ All assignments → Assignments
- ❌ Does NOT modify Google Classroom
- ❌ Read-only access (safe)

### Syncing
- Click "🔗 Sync Now" anytime
- Updates existing courses/assignments
- Doesn't delete your edits
- Can sync multiple times

## Homework Helper

### Setup
See [HOMEWORK_HELPER_GUIDE.md](./HOMEWORK_HELPER_GUIDE.md) for detailed guide.

**Quick setup:**
1. Get API key from [console.anthropic.com](https://console.anthropic.com)
2. Add to `.env.local`: `ANTHROPIC_API_KEY=key`
3. Restart dev server
4. Click "🤖 Helper"
5. Start asking questions!

### Best Questions
- "Explain photosynthesis step-by-step"
- "How do I solve quadratic equations?"
- "What's the difference between X and Y?"
- "Can you give examples of how X is used?"

### Not Recommended
- "Do my homework"
- "Give me the answer"
- Generic questions
- Very vague requests

## Tips & Best Practices

### Daily Routine
1. **Morning**: Check Dashboard for today's tasks
2. **Throughout day**: Update assignment progress
3. **After class**: Add notes while fresh
4. **Evening**: Use Homework Helper for confusing concepts
5. **Weekly**: Review grades and performance

### Organization Tips
- Create subject for each course
- Use priorities (High for urgent)
- Save important notes with ⭐
- Link homework help to subjects
- Regularly review and delete old items

### Study Tips
- Use notes to study before tests
- Review saved homework help responses
- Track grades to identify weak areas
- Ask homework helper specific questions
- Don't rely solely on AI (verify with texts)

### Before Tests
1. Review all saved notes (⭐)
2. Look at saved homework help
3. Review grades and weak areas
4. Ask homework helper practice questions
5. Study with classmates if possible

## Troubleshooting

### Can't Sign In
**Issue**: "Sign in with Google" doesn't work

**Solutions**:
- Check GOOGLE_CLIENT_ID and SECRET in .env.local
- Verify OAuth redirect URI is correct
- Ensure Google Cloud project is set up
- Try incognito/private window
- Check browser console for errors

### Database Connection Error
**Issue**: "Failed to connect to database"

**Solutions**:
- Ensure PostgreSQL is running
- Check DATABASE_URL is correct
- Verify database exists
- Check credentials (user/password)
- Try: `psql your_connection_string`

### Google Classroom Won't Sync
**Issue**: Sync button doesn't work or gives error

**Solutions**:
- Sign out and sign in again
- Check that Classroom API is enabled
- Verify you have courses in Google Classroom
- Check GOOGLE_CLIENT_ID is correct
- Look at browser console for errors

### Homework Helper Not Working
**Issue**: "AI service not configured" error

**Solutions**:
- Add ANTHROPIC_API_KEY to .env.local
- Verify key is valid at console.anthropic.com
- Restart dev server after adding key
- Check you have free credits
- Check browser console for API errors

### Slow Performance
**Issue**: App is slow or sluggish

**Solutions**:
- Clear browser cache
- Refresh the page
- Check internet connection
- Stop other apps using resources
- Restart development server

### Data Not Showing
**Issue**: Subjects, assignments, etc. don't appear

**Solutions**:
- Refresh the page
- Check filters aren't hiding data
- Make sure you've added items
- Sign out and sign in again
- Check browser console for errors

## Production Deployment

### Before Deploying

1. **Update Environment Variables**
```env
NEXTAUTH_URL=https://yourdomain.com
DATABASE_URL=your_production_database
GOOGLE_CLIENT_ID=your_production_client_id
# ... etc
```

2. **Update Google OAuth**
   - Add production domain to redirect URIs
   - Format: `https://yourdomain.com/api/auth/callback/google`

3. **Build Production**
```bash
npm run build
npm run start
```

### Deployment Options
- Vercel (recommended, free for Next.js)
- Heroku
- AWS
- DigitalOcean
- Railway
- Any Node.js host

### Vercel Deployment
1. Push code to GitHub
2. Go to vercel.com
3. Connect GitHub repo
4. Add environment variables
5. Deploy!

## Documentation Links

- **README.md** - Project overview
- **GOOGLE_CLASSROOM_SETUP.md** - Detailed Classroom integration
- **GOOGLE_CLASSROOM_ADDED.md** - Technical details
- **HOMEWORK_HELPER_GUIDE.md** - Homework Helper guide
- **.env.example** - Environment variables template

## Support & FAQ

### Q: Can I use without Google Classroom?
A: Yes! All core features work without it. Just skip the sign-in.

### Q: Is Homework Helper always required?
A: No, it's optional. Skip if you don't need AI help.

### Q: Can I export my data?
A: Coming in future versions. For now, data is in PostgreSQL.

### Q: How do I delete my account?
A: You can delete data by not using the app. Google/Anthropic have their own policies.

### Q: Is my data private?
A: Yes. Data is stored locally. We don't share it.

### Q: Can I modify the app?
A: Yes! It's built with Next.js, React, and open source tools.

### Q: How do I report bugs?
A: Check GitHub issues or contact support.

### Q: Can I get support?
A: See documentation files first. Check guides for common issues.

## Next Steps

1. **Set up the app** using this guide
2. **Add your subjects** for your courses
3. **Start adding assignments** and tracking them
4. **Add grades** to track performance
5. **Create study notes** for difficult topics
6. **(Optional) Connect Google Classroom** to auto-import
7. **(Optional) Use Homework Helper** for learning support

---

**You're all set!** 🎉

Start by clicking "Subjects" and adding your courses. Then explore other features.

Good luck with your studies! 📚✨
