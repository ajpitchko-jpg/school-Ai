# 📚 Reading Helper - Complete Guide

The Reading Helper is an innovative feature that generates comprehensive summaries and AI-narrated audio for any book chapter you're reading. Perfect for students, busy professionals, or anyone who loves literature!

## Features

### 📖 Core Functionality
- ✅ **Instant Summaries** - AI-generated chapter summaries in seconds
- ✅ **Audio Narration** - Listen to summaries as professional text-to-speech audio
- ✅ **Save Readings** - Bookmark important chapters for later
- ✅ **Full History** - Access all summaries you've generated
- ✅ **Subject Linking** - Organize readings by your courses
- ✅ **Audio Controls** - Play, pause, and listen at your convenience

### 🎯 What It Can Summarize
- Classic Literature (Shakespeare, Jane Austen, Charles Dickens, etc.)
- Modern Novels (Contemporary bestsellers)
- Academic Textbooks (History, Science, Literature)
- Educational Books (Philosophy, Self-help, Business)
- Any book you're reading for class or pleasure!

## Setup

### Prerequisites
1. **School Helper Account** - Must be signed in
2. **Anthropic API Key** - For summaries (Claude AI)
3. **OpenAI API Key** - For audio narration (optional but recommended)

### Step 1: Get API Keys

**Anthropic API (Required for summaries):**
1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Sign up or log in
3. Navigate to "API Keys"
4. Click "Create Key"
5. Copy the generated key

**OpenAI API (Optional for audio):**
1. Go to [platform.openai.com](https://platform.openai.com)
2. Sign up or log in
3. Navigate to "API Keys"
4. Click "Create new secret key"
5. Copy the generated key

### Step 2: Add to Environment

1. Open `.env.local` in your project root
2. Make sure you have:
```env
ANTHROPIC_API_KEY=your_anthropic_key
OPENAI_API_KEY=your_openai_key
```

3. Restart your development server:
```bash
npm run dev
```

### Step 3: Access Reading Helper

1. Sign in to School Helper
2. Click "📚 Reading" in navigation
3. Start generating summaries!

## How to Use

### Generating a Reading Summary

1. **Go to "Generate Summary" tab**
   - This is the default tab when you open Reading Helper

2. **Fill in the form:**
   - **Book Title** - Name of the book
     - Examples: "To Kill a Mockingbird", "1984", "Pride and Prejudice"
   - **Chapter** - Which chapter to summarize
     - Examples: "Chapter 1", "Chapter 5: The Trial Begins", "Part 2, Chapter 3"
   - **Subject** (Optional) - Link to one of your courses

3. **Click "✨ Generate"**
   - The AI will create a summary
   - If OpenAI is set up, it will also generate audio
   - Wait a few seconds for processing

4. **Review the Summary**
   - Read through the generated content
   - Listen to the audio narration
   - Save it if you found it helpful

### Listening to Audio

**While viewing a summary:**
1. Scroll to the "🎧 Listen to Summary" section
2. Click the play button
3. Adjust volume as needed
4. Playback controls appear automatically

**In History:**
1. Click the 🎧 button to preview audio
2. Inline player appears below the summary
3. Great for quick review while browsing

### Saving Summaries

1. **Click "☆ Save"** button on any summary
   - The button changes to "⭐ Saved"
   - Summary is bookmarked for later

2. **Access saved summaries** in the "My Readings" tab
   - Click "⭐ Saved" filter
   - View only your bookmarked summaries

### Viewing History

1. **Click "📚 My Readings" tab**
   - See all generated summaries
   - Click any to view again

2. **Filter options:**
   - **All** - View all summaries generated
   - **⭐ Saved** - View only bookmarked items

3. **Manage summaries:**
   - Click any summary to view full content
   - Click 🎧 to play audio (if available)
   - Click 🗑️ to delete

## Example Uses

### For Students

**Literature Class:**
- Q: "The Great Gatsby, Chapter 3"
- Gets: Detailed summary of the famous party, themes, character development, and connections to the novel

**History Class:**
- Q: "A Brief History of Time, Chapter 2"
- Gets: Summary of key physics concepts explained in a student-friendly way

**Language Class:**
- Q: "Le Petit Prince, Chapter 1"
- Gets: Summary of the book in relation to French literature and culture

### For Busy Readers

**Commuting:**
- Generate summary in morning
- Listen to audio on the way to school
- Already prepared for class discussion

**Studying:**
- Create summaries of chapters before tests
- Save important ones
- Review saved summaries the night before

**Book Club:**
- Quick summaries before meetings
- Review key points and themes
- Impress with detailed knowledge

### For ESL/Second Language Students

- Read summaries in English while learning
- Listen to native pronunciation
- Understand literary context better
- Learn vocabulary in context

## API Details

### Endpoints

**Generate Summary**
```
POST /api/reading/summarize
Body: {
  book: string,           // Book title
  chapter: string,        // Chapter description
  subjectId?: string      // Optional: subject ID
}
```

**Get History**
```
GET /api/reading/history?saved=true&subjectId=1
```

**Update Summary**
```
PUT /api/reading/[id]
Body: { saved: boolean }
```

**Delete Summary**
```
DELETE /api/reading/[id]
```

## Pricing & Costs

### Anthropic API (Summaries)
- Approximately $0.003 per 1K input tokens
- $0.015 per 1K output tokens
- Average summary: ~$0.01

### OpenAI API (Audio)
- Text-to-speech: $0.015 per 1K characters
- Average chapter audio: ~$0.05-0.15
- First month free: $5 trial credit

### Total per Reading
- Summary only: ~$0.01
- Summary + Audio: ~$0.06-0.20
- 50 readings: ~$3-10 depending on chapter length

### Budget Tips
- Use Anthropic free trial credits first
- Get OpenAI free trial credits
- Generate summaries for chapters you really need
- Share summaries with classmates
- Set API spending limits in console

## Best Practices

### ✅ Do This

**Be Specific with Chapters:**
- ✓ "Chapter 5: The Trial Begins"
- ✓ "Part 2, Chapter 3"
- ✓ "The Duel - Act III"
- Better summaries with more specific chapter info

**Link to Subjects:**
- Link to English for literature
- Link to History for historical books
- Makes organizing easier

**Save Important Ones:**
- Save chapters before tests
- Save key chapters you struggled with
- Build a library of important summaries

**Use Audio Wisely:**
- Listen while exercising
- Listen while commuting
- Listen while doing homework
- Great for multi-tasking studying

### ❌ Avoid This

- Don't ask for "the whole book" - summarize chapter by chapter
- Don't rely solely on summaries - read the actual book!
- Don't share others' summaries without crediting
- Don't use for plagiarism - these are study aids only

## Troubleshooting

### "AI service not configured" Error
**Solution**:
- Make sure ANTHROPIC_API_KEY is in .env.local
- Restart dev server after adding the key
- Verify key is valid at console.anthropic.com

### Audio Not Generating
**Solutions**:
- OPENAI_API_KEY might be missing
- It's optional - summaries work without audio
- Add the key to .env.local if you want audio
- Restart dev server

### Slow Generation
**Solutions**:
- This is normal - summaries take 10-30 seconds
- Longer chapters take longer
- Check your internet connection
- API might be busy (retry in a moment)

### Wrong Information in Summary
**Solutions**:
- AI makes mistakes sometimes
- Always read the actual chapter too
- Use summaries as supplements, not replacements
- Verify important facts in the original text

### Can't Save Summaries
**Solutions**:
- Make sure you're signed in
- Try refreshing the page
- Check browser console for errors

## Learning Integration

### Before Reading Chapter
1. Generate summary
2. Read the summary first
3. Familiarize yourself with themes and plot
4. Then read the actual chapter
5. You'll understand better!

### While Reading
- Reference the summary if confused
- Note differences between summary and your reading
- Identify main points mentioned in summary

### After Reading
- Review summary to confirm understanding
- Listen to audio while reviewing notes
- Save if important for your class
- Compare notes with summary

### Studying for Tests
1. Review all saved summaries
2. Listen to audio of key chapters
3. Make flashcards from summaries
4. Quiz yourself on plot/themes
5. Feel confident going into the test!

## FAQ

**Q: Will using summaries hurt my reading?**
A: No! Summaries are study aids. Read the book, use summaries to understand better.

**Q: Can I use these for book reports?**
A: The summaries help you understand - YOU write the report. Using summaries verbatim is plagiarism.

**Q: What if the summary is wrong?**
A: AI makes mistakes. Always verify with the original text. Trust the book, not the AI.

**Q: Does this work for all books?**
A: Best for books published and discussed widely. Obscure books might get generic summaries.

**Q: Can I download the audio?**
A: Audio is streamed from the server. You can use browser tools to save if needed.

**Q: How long are summaries?**
A: Usually 300-400 words, about 2-5 minutes to read aloud.

**Q: Can I use this for manga/graphic novels?**
A: The descriptions might work, but summaries won't include visual elements.

**Q: Is my reading history private?**
A: Yes! Your summaries are stored in your database only.

## Advanced Tips

### Organize by Subject
- Create subjects for each class
- Link readings to relevant subjects
- Easy to find later

### Create Study Sessions
- Generate summaries week by week
- Save all chapter summaries
- Review before class discussion
- Create study guides from summaries

### Group Reading
- Share summaries with study group
- Discuss key points together
- Compare understanding
- Learn from each other

### Different Reading Speeds
- Slow readers: Get summary first for context
- Fast readers: Use summaries for review
- Busy readers: Listen to audio for quick learning

## Comparison: Summary Only vs. Summary + Audio

| Feature | Summary Only | Summary + Audio |
|---------|-------------|-----------------|
| Reading comprehension | ✓ Excellent | ✓ Excellent |
| Learning style options | - Text only | ✓ Auditory + Visual |
| Time to use | ✓ 5 min read | 5 min read + listen |
| Multitasking | - Must focus | ✓ Can listen while doing other things |
| Cost | Lower | Higher |
| Accessibility | Good | ✓ Better (hearing learners) |

## Pro Tips

1. **Save your favorites** - Build a personal library over the semester
2. **Listen before bed** - Helps with retention through sleep
3. **Read summary first** - Provides framework before reading chapter
4. **Use for difficult chapters** - Extra help for confusing parts
5. **Compare summaries** - Generate again to see variations
6. **Link to subjects** - Organize by course for easy access
7. **Review before tests** - Your summaries become study guides
8. **Share with classmates** - (But write your own analysis!)

## Common Books Supported

**Classics:**
- Pride and Prejudice
- To Kill a Mockingbird
- 1984
- The Great Gatsby
- Wuthering Heights
- Jane Eyre

**Modern Literature:**
- The Hunger Games
- Harry Potter series
- Percy Jackson series
- A Song of Ice and Fire
- The Lord of the Rings

**Academic:**
- Sapiens
- Thinking, Fast and Slow
- Brief History of Time
- Capital
- The Republic (Plato)

And thousands more!

---

**Happy reading!** 📚✨

Remember: Summaries are tools to help you learn, not shortcuts to avoid reading. The best way to enjoy books is to read them yourself!

Questions? See the troubleshooting section or check your API configuration.
