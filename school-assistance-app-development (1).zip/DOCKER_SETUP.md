# 🐳 School Helper - Docker Setup Guide

This guide explains how to run School Helper as a single packaged application using Docker.

## What is Docker?

Docker packages your entire application (code, database, dependencies) into a single container that runs the same way on any computer - Mac, Windows, or Linux.

## Prerequisites

You only need **one thing installed**:
- **Docker Desktop** - Download from https://www.docker.com/products/docker-desktop

That's it! No need to install Node.js, PostgreSQL, or anything else.

## Installation & Setup

### Option 1: Automatic Setup (Easiest)

#### On Mac/Linux:
```bash
# Make the script executable
chmod +x setup.sh

# Run the setup script
./setup.sh
```

#### On Windows:
```bash
# Double-click setup.bat
# OR run in Command Prompt
setup.bat
```

The script will:
1. Check if Docker is installed
2. Create configuration files
3. Build the Docker images
4. Start all services
5. Initialize the database

### Option 2: Manual Setup

```bash
# Build the Docker images
docker-compose build

# Start the services
docker-compose up -d

# Initialize the database (wait a few seconds first)
docker-compose exec app npm run db:init
```

## Accessing School Helper

Once setup is complete, open your browser:

```
http://localhost:3000
```

That's it! The app is running.

## Configuration

### Adding API Keys for Features

Edit `.env.local` to add optional API keys:

```bash
# Open .env.local in your text editor
nano .env.local  # or use your favorite editor
```

**For Google Classroom:**
```env
GOOGLE_CLIENT_ID=your_id_here
GOOGLE_CLIENT_SECRET=your_secret_here
```

**For Homework Helper (Claude AI):**
```env
ANTHROPIC_API_KEY=your_key_here
```

**For Reading Helper Audio:**
```env
OPENAI_API_KEY=your_key_here
```

After editing, restart the app:
```bash
docker-compose restart app
```

## Common Commands

### View Logs
```bash
# See what's happening
docker-compose logs -f app

# Press Ctrl+C to stop viewing logs
```

### Stop the App
```bash
# Stop all services (data is saved)
docker-compose down

# Later, restart with:
docker-compose up -d
```

### Restart Services
```bash
# Restart the app
docker-compose restart app

# Restart the database
docker-compose restart database
```

### Database Shell
```bash
# Access PostgreSQL database
docker-compose exec database psql -U postgres -d app_db
```

### App Shell
```bash
# Run commands inside the app container
docker-compose exec app /bin/sh

# Example: check node version
docker-compose exec app node --version
```

## Backup Your Data

Your data is stored in Docker volumes. To backup:

### Create a Backup
```bash
# Export database
docker-compose exec database pg_dump -U postgres app_db > backup.sql
```

### Restore a Backup
```bash
# Import database
docker-compose exec -T database psql -U postgres app_db < backup.sql
```

## Troubleshooting

### "Docker is not installed"
**Solution:** Download and install Docker Desktop from https://www.docker.com/products/docker-desktop

### "Port 3000 is already in use"
**Solution:** Either:
1. Stop the other app using port 3000
2. Or change the port in `docker-compose.yml` (change `3000:3000` to `8000:3000`)

### "Permission denied" (on Mac/Linux)
**Solution:**
```bash
sudo chmod +x setup.sh
sudo ./setup.sh
```

### App won't start or crashes
**Solution:**
```bash
# Check the logs
docker-compose logs -f app

# Try rebuilding
docker-compose build --pull
docker-compose up -d
```

### Database connection error
**Solution:**
```bash
# Restart the database
docker-compose restart database

# Wait 10 seconds, then restart the app
docker-compose restart app
```

### Can't access audio files
**Solution:** Create the audio directory:
```bash
mkdir -p public/audio
docker-compose restart app
```

## Performance Tips

### Free up disk space
```bash
# Remove unused Docker images
docker image prune

# Remove unused volumes
docker volume prune

# Clean everything (careful!)
docker system prune -a
```

### Speed up database
The database is optimized for development. For production, you might want:
1. More RAM allocated to Docker
2. SSD storage
3. PostgreSQL performance tuning

### Monitor resource usage
```bash
# See CPU, memory, network usage
docker stats
```

## Production Deployment

For production, consider:

1. **Use a cloud database** instead of Docker's PostgreSQL
2. **Use Docker Hub** to host images
3. **Use Kubernetes** for scaling
4. **Set up HTTPS** with a reverse proxy (nginx)
5. **Add environment-specific configs**

See the main README.md for production deployment options.

## File Locations

### Configuration
- `.env.local` - Environment variables
- `docker-compose.yml` - Docker services definition
- `Dockerfile` - Container build instructions

### Data
- `postgres_data` - Database files (persisted)
- `public/audio` - Reading helper audio files

### Logs
```bash
# View logs from any service
docker-compose logs service_name

# service_name can be: app, database
```

## Advanced Usage

### Custom Database Port
Edit `docker-compose.yml`:
```yaml
database:
  ports:
    - "5432:5432"  # Change first number for external access
```

### Custom App Port
Edit `docker-compose.yml`:
```yaml
app:
  ports:
    - "3000:3000"  # Change first number
```

### Scale the App
For multiple instances:
```bash
docker-compose up -d --scale app=3
```

(Requires load balancer setup)

### Use Different Databases

#### PostgreSQL 16 (newer)
Edit `docker-compose.yml`:
```yaml
database:
  image: postgres:16-alpine
```

#### PostgreSQL 14 (older)
Edit `docker-compose.yml`:
```yaml
database:
  image: postgres:14-alpine
```

## Getting Help

1. **Check logs** - Usually shows the problem
   ```bash
   docker-compose logs -f
   ```

2. **Read error messages** - They usually explain the issue

3. **Check Docker is running** - Make sure Docker Desktop is open

4. **Restart everything** - Sometimes fixes issues
   ```bash
   docker-compose down
   docker-compose up -d
   ```

5. **Rebuild from scratch** - Nuclear option
   ```bash
   docker-compose down -v
   docker-compose build --pull
   docker-compose up -d
   ```

## What Happens Behind the Scenes?

When you run `docker-compose up -d`:

1. **Database Service (PostgreSQL)**
   - Starts a PostgreSQL database
   - Stores your data in `postgres_data` volume
   - Listens on port 5432 (internal only)

2. **App Service (Next.js)**
   - Builds the Next.js application
   - Runs the production server
   - Listens on port 3000
   - Waits for database to be ready
   - Runs health checks every 30 seconds

3. **Networking**
   - Services can talk to each other
   - App connects to database at `postgresql://postgres:postgres@database:5432/app_db`

4. **Persistence**
   - Database data saved in `postgres_data` volume
   - Data survives container restarts
   - Audio files saved in `public/audio`

## Docker Advantages

✅ **One-file setup** - Just download and run
✅ **No installation** - Works on any machine
✅ **Easy backup** - Everything is containerized
✅ **Easy sharing** - Share the docker-compose.yml file
✅ **Production-ready** - Same setup as production
✅ **Clean system** - No pollution of your system files
✅ **Multiple instances** - Run multiple versions

## Comparison

| Feature | Docker | Traditional |
|---------|--------|-------------|
| Setup time | 5 minutes | 30+ minutes |
| Dependencies | Just Docker | Node, PostgreSQL, etc. |
| Updates | One-click build | Manual updates |
| Sharing | One file | Many files |
| Portability | Works everywhere | Platform-dependent |
| Cleanup | One command | Manual cleanup |

---

**Docker makes deployment simple!** 🐳

Questions? Check the troubleshooting section or see COMPLETE_SETUP_GUIDE.md.
