#!/bin/bash

# School Helper - Setup Script
# This script sets up and runs School Helper with Docker

set -e

echo "╔════════════════════════════════════════════════════════════════════╗"
echo "║                    📚 SCHOOL HELPER SETUP                          ║"
echo "║                                                                    ║"
echo "║         Your AI-powered academic companion - One file setup        ║"
echo "╚════════════════════════════════════════════════════════════════════╝"
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed!"
    echo ""
    echo "Please install Docker from: https://www.docker.com/products/docker-desktop"
    echo ""
    exit 1
fi

echo "✅ Docker is installed"
echo ""

# Check if docker-compose is available
if ! command -v docker-compose &> /dev/null; then
    echo "⚠️  docker-compose not found, trying docker compose..."
    DOCKER_COMPOSE="docker compose"
else
    DOCKER_COMPOSE="docker-compose"
fi

echo "📝 Setting up environment variables..."
echo ""

# Create .env file if it doesn't exist
if [ ! -f ".env.local" ]; then
    cat > .env.local << 'EOF'
# Database (auto-configured with Docker)
DATABASE_URL=postgresql://postgres:postgres@database:5432/app_db

# NextAuth Configuration
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=school-helper-secret-key-change-in-production

# Google Classroom (Optional - Leave empty to skip)
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=

# Anthropic API (Optional - For Homework Helper)
ANTHROPIC_API_KEY=

# OpenAI API (Optional - For Reading Helper Audio)
OPENAI_API_KEY=
EOF
    echo "✅ Created .env.local"
    echo ""
    echo "📋 To enable features, edit .env.local and add your API keys:"
    echo "   • Google Classroom: https://console.cloud.google.com"
    echo "   • Homework Helper: https://console.anthropic.com"
    echo "   • Reading Helper Audio: https://platform.openai.com"
    echo ""
    read -p "Press Enter to continue (you can add keys later)..."
else
    echo "✅ .env.local already exists"
fi

echo ""
echo "🐳 Building Docker images..."
echo ""

# Build the Docker images
$DOCKER_COMPOSE build --pull

echo ""
echo "🚀 Starting School Helper..."
echo ""

# Start the services
$DOCKER_COMPOSE up -d

echo ""
echo "⏳ Waiting for database to be ready..."
sleep 10

echo ""
echo "🗄️  Initializing database..."

# Run database migrations
$DOCKER_COMPOSE exec -T app npm run db:init || true

echo ""
echo "╔════════════════════════════════════════════════════════════════════╗"
echo "║                   ✅ SETUP COMPLETE!                              ║"
echo "╚════════════════════════════════════════════════════════════════════╝"
echo ""
echo "📚 School Helper is now running!"
echo ""
echo "🌐 Open your browser and go to: http://localhost:3000"
echo ""
echo "📊 Features:"
echo "   ✓ Academic Management (Subjects, Assignments, Grades, Notes, Schedule)"
echo "   ✓ Google Classroom Integration (Optional)"
echo "   ✓ Homework Helper with AI (Optional)"
echo "   ✓ Reading Helper with Audio (Optional)"
echo ""
echo "⌨️  Useful Commands:"
echo "   • View logs:     $DOCKER_COMPOSE logs -f app"
echo "   • Stop app:      $DOCKER_COMPOSE down"
echo "   • Restart app:   $DOCKER_COMPOSE restart app"
echo "   • Shell access:  $DOCKER_COMPOSE exec app /bin/sh"
echo ""
echo "💾 Your data is saved in PostgreSQL and persists between restarts"
echo ""
echo "📖 Documentation: See README.md and COMPLETE_SETUP_GUIDE.md"
echo ""
