'use client';

import { useSession, signOut } from 'next-auth/react';
import { useState } from 'react';

export default function UserMenu() {
  const { data: session } = useSession();
  const [isOpen, setIsOpen] = useState(false);

  if (!session) return null;

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 text-slate-700 hover:text-blue-600 font-medium"
      >
        {session.user?.image && (
          <img
            src={session.user.image}
            alt="Profile"
            className="w-8 h-8 rounded-full"
          />
        )}
        <span className="hidden sm:inline max-w-[100px] truncate">{session.user?.name}</span>
        <span className="text-sm">▼</span>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-slate-200 z-50">
          <div className="px-4 py-3 border-b border-slate-200">
            <p className="text-sm font-medium text-slate-900">{session.user?.name}</p>
            <p className="text-xs text-slate-600">{session.user?.email}</p>
          </div>
          <button
            onClick={() => {
              setIsOpen(false);
              signOut({ redirect: true, redirectTo: '/login' } as any);
            }}
            className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-100 transition"
          >
            Sign Out
          </button>
        </div>
      )}
    </div>
  );
}
