'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';

export default function GoogleClassroomSync() {
  const { data: session } = useSession();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleSync = async () => {
    if (!session) return;

    setLoading(true);
    setMessage(null);

    try {
      const res = await fetch('/api/classroom/sync', {
        method: 'POST',
      });

      const data = await res.json();

      if (res.ok) {
        setMessage({
          type: 'success',
          text: data.message || 'Synced successfully!',
        });
        // Refresh the page after 2 seconds
        setTimeout(() => window.location.reload(), 2000);
      } else {
        setMessage({
          type: 'error',
          text: data.error || 'Failed to sync',
        });
      }
    } catch (error) {
      setMessage({
        type: 'error',
        text: 'An error occurred during sync',
      });
    } finally {
      setLoading(false);
    }
  };

  if (!session) return null;

  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="font-semibold text-slate-900">Google Classroom</h3>
          <p className="text-sm text-slate-600 mt-1">
            Sync your courses and assignments from Google Classroom
          </p>
        </div>
        <button
          onClick={handleSync}
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-semibold py-2 px-4 rounded-lg transition"
        >
          {loading ? '🔄 Syncing...' : '🔗 Sync Now'}
        </button>
      </div>
      {message && (
        <div
          className={`mt-3 p-3 rounded text-sm ${
            message.type === 'success'
              ? 'bg-green-100 text-green-800'
              : 'bg-red-100 text-red-800'
          }`}
        >
          {message.text}
        </div>
      )}
    </div>
  );
}
