'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import ReactMarkdown from 'react-markdown';

interface Subject {
  id: number;
  name: string;
  code: string;
}

interface ReadingSummary {
  id: number;
  book: string;
  chapter: string;
  summary: string;
  audioUrl?: string;
  duration?: number;
  saved: boolean;
  subjectId?: number;
  createdAt: string;
}

export default function ReadingPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [history, setHistory] = useState<ReadingSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState<'create' | 'history'>('create');
  const [formData, setFormData] = useState({
    book: '',
    chapter: '',
    subjectId: '',
  });
  const [currentReading, setCurrentReading] = useState<ReadingSummary | null>(null);
  const [savedOnly, setSavedOnly] = useState(false);
  const [playingAudioId, setPlayingAudioId] = useState<number | null>(null);

  useEffect(() => {
    if (!session) {
      router.push('/login');
      return;
    }
    fetchSubjects();
    fetchHistory();
  }, [session, router]);

  const fetchSubjects = async () => {
    try {
      const res = await fetch('/api/subjects');
      const data = await res.json();
      setSubjects(data);
    } catch (error) {
      console.error('Error fetching subjects:', error);
    }
  };

  const fetchHistory = async () => {
    try {
      const res = await fetch('/api/reading/history');
      const data = await res.json();
      setHistory(data);
    } catch (error) {
      console.error('Error fetching history:', error);
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.book.trim() || !formData.chapter.trim()) {
      alert('Please fill in both book and chapter');
      return;
    }

    setGenerating(true);

    try {
      const res = await fetch('/api/reading/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          book: formData.book,
          chapter: formData.chapter,
          subjectId: formData.subjectId || null,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setCurrentReading({
          id: data.id,
          book: formData.book,
          chapter: formData.chapter,
          summary: data.summary,
          audioUrl: data.audioUrl,
          duration: data.duration,
          saved: false,
          subjectId: formData.subjectId ? parseInt(formData.subjectId) : undefined,
          createdAt: new Date().toISOString(),
        });
        setFormData({ book: '', chapter: '', subjectId: '' });
        setActiveTab('create');
        setTimeout(fetchHistory, 1000);
      } else {
        const error = await res.json();
        alert(error.error || 'Failed to generate summary');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred. Make sure ANTHROPIC_API_KEY and OPENAI_API_KEY are set.');
    } finally {
      setGenerating(false);
    }
  };

  const handleSave = async (id: number) => {
    try {
      const res = await fetch(`/api/reading/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ saved: true }),
      });

      if (res.ok) {
        if (currentReading?.id === id) {
          setCurrentReading({ ...currentReading, saved: true });
        }
        fetchHistory();
      }
    } catch (error) {
      console.error('Error saving:', error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this reading summary?')) return;

    try {
      const res = await fetch(`/api/reading/${id}`, { method: 'DELETE' });

      if (res.ok) {
        if (currentReading?.id === id) {
          setCurrentReading(null);
        }
        fetchHistory();
      }
    } catch (error) {
      console.error('Error deleting:', error);
    }
  };

  const formatDuration = (seconds?: number) => {
    if (!seconds) return '';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const subjectMap = new Map(subjects.map((s) => [s.id, s]));
  const filteredHistory = savedOnly ? history.filter((h) => h.saved) : history;

  if (!session) {
    return (
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <p className="text-center text-slate-600">Please sign in to use reading helper.</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold text-slate-900 mb-8">📚 Reading Helper</h1>

      {/* Tabs */}
      <div className="flex gap-4 mb-8">
        <button
          onClick={() => setActiveTab('create')}
          className={`px-6 py-3 rounded-lg font-semibold transition ${
            activeTab === 'create'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
          }`}
        >
          📖 Generate Summary
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`px-6 py-3 rounded-lg font-semibold transition ${
            activeTab === 'history'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
          }`}
        >
          📚 My Readings ({history.length})
        </button>
      </div>

      {/* Create Tab */}
      {activeTab === 'create' && (
        <div className="space-y-6">
          {/* Form */}
          <div className="bg-white rounded-lg p-8 shadow-sm border border-slate-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Create Reading Summary</h2>
            <form onSubmit={handleGenerate} className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Book Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.book}
                    onChange={(e) => setFormData({ ...formData, book: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g., To Kill a Mockingbird"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Chapter *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.chapter}
                    onChange={(e) => setFormData({ ...formData, chapter: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g., Chapter 5"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Subject (Optional)
                </label>
                <select
                  value={formData.subjectId}
                  onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select a subject</option>
                  {subjects.map((subject) => (
                    <option key={subject.id} value={subject.id}>
                      {subject.name}
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                disabled={generating}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-semibold py-3 px-6 rounded-lg transition"
              >
                {generating ? '🔄 Generating Summary & Audio...' : '✨ Generate'}
              </button>
            </form>

            <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-800">
                💡 This will create a detailed summary of the chapter and generate an audio recording
                you can listen to while studying!
              </p>
            </div>
          </div>

          {/* Current Reading */}
          {currentReading && (
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-8 shadow-sm border border-blue-200">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">{currentReading.book}</h3>
                  <p className="text-lg text-slate-700 mt-1">📖 {currentReading.chapter}</p>
                  {currentReading.subjectId && (
                    <p className="text-sm text-slate-600 mt-1">
                      {subjectMap.get(currentReading.subjectId)?.name}
                    </p>
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleSave(currentReading.id)}
                    disabled={currentReading.saved}
                    className="text-amber-600 hover:text-amber-700 font-medium text-sm disabled:text-gray-400"
                  >
                    {currentReading.saved ? '⭐ Saved' : '☆ Save'}
                  </button>
                  <button
                    onClick={() => {
                      handleDelete(currentReading.id);
                      setCurrentReading(null);
                    }}
                    className="text-red-600 hover:text-red-700 font-medium text-sm"
                  >
                    🗑️
                  </button>
                </div>
              </div>

              {/* Audio Player */}
              {currentReading.audioUrl && (
                <div className="mb-6 p-4 bg-white rounded-lg border border-slate-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-slate-900 mb-2">🎧 Listen to Summary</p>
                      <p className="text-sm text-slate-600">
                        Duration: {formatDuration(currentReading.duration)}
                      </p>
                    </div>
                    <audio controls className="w-full max-w-sm">
                      <source src={currentReading.audioUrl} type="audio/mpeg" />
                      Your browser does not support the audio element.
                    </audio>
                  </div>
                </div>
              )}

              {/* Summary */}
              <div>
                <h4 className="font-semibold text-slate-900 mb-3">📋 Chapter Summary:</h4>
                <div className="bg-white rounded p-6 border border-slate-200 prose prose-sm max-w-none">
                  <ReactMarkdown
                    components={{
                      p: ({ node, ...props }) => <p className="text-slate-700 mb-4" {...props} />,
                      h1: ({ node, ...props }) => (
                        <h1 className="text-2xl font-bold text-slate-900 mt-6 mb-4" {...props} />
                      ),
                      h2: ({ node, ...props }) => (
                        <h2 className="text-xl font-bold text-slate-900 mt-5 mb-3" {...props} />
                      ),
                      h3: ({ node, ...props }) => (
                        <h3 className="text-lg font-bold text-slate-900 mt-4 mb-2" {...props} />
                      ),
                      ul: ({ node, ...props }) => (
                        <ul className="list-disc list-inside text-slate-700 mb-4 space-y-2" {...props} />
                      ),
                      ol: ({ node, ...props }) => (
                        <ol className="list-decimal list-inside text-slate-700 mb-4 space-y-2" {...props} />
                      ),
                      li: ({ node, ...props }) => <li className="text-slate-700" {...props} />,
                      strong: ({ node, ...props }) => (
                        <strong className="font-bold text-slate-900" {...props} />
                      ),
                    }}
                  >
                    {currentReading.summary}
                  </ReactMarkdown>
                </div>
              </div>

              <p className="text-xs text-slate-600 mt-4">
                Generated on {new Date(currentReading.createdAt).toLocaleString()}
              </p>
            </div>
          )}

          {/* Tips */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-6">
            <h3 className="font-semibold text-amber-900 mb-3">💡 Tips:</h3>
            <ul className="space-y-2 text-sm text-amber-800">
              <li>✓ Be specific with the chapter (e.g., "Chapter 5: The Trial Begins")</li>
              <li>✓ Summaries work best for books in English</li>
              <li>✓ Save important summaries for later review</li>
              <li>✓ Use audio while commuting or exercising</li>
              <li>✓ Great for studying and test preparation</li>
            </ul>
          </div>
        </div>
      )}

      {/* History Tab */}
      {activeTab === 'history' && (
        <div className="space-y-6">
          {/* Filter */}
          <div className="flex gap-4">
            <button
              onClick={() => setSavedOnly(false)}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                !savedOnly
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
              }`}
            >
              All ({history.length})
            </button>
            <button
              onClick={() => setSavedOnly(true)}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                savedOnly
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
              }`}
            >
              ⭐ Saved ({history.filter((h) => h.saved).length})
            </button>
          </div>

          {/* History List */}
          {filteredHistory.length > 0 ? (
            <div className="space-y-4">
              {filteredHistory.map((reading) => (
                <div
                  key={reading.id}
                  className="bg-white rounded-lg p-6 shadow-sm border border-slate-200 hover:shadow-md transition cursor-pointer"
                  onClick={() => {
                    setCurrentReading(reading);
                    setActiveTab('create');
                  }}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-slate-900">{reading.book}</h3>
                      <p className="text-sm text-slate-600 mt-1">📖 {reading.chapter}</p>
                      {reading.subjectId && (
                        <p className="text-sm text-slate-600">
                          📚 {subjectMap.get(reading.subjectId)?.name}
                        </p>
                      )}
                      <p className="text-xs text-slate-500 mt-2">
                        {new Date(reading.createdAt).toLocaleDateString()} at{' '}
                        {new Date(reading.createdAt).toLocaleTimeString()}
                      </p>
                    </div>
                    <div className="flex gap-2 ml-4">
                      {reading.audioUrl && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setPlayingAudioId(playingAudioId === reading.id ? null : reading.id);
                          }}
                          className="text-blue-600 hover:text-blue-700 font-medium text-lg"
                        >
                          🎧
                        </button>
                      )}
                      {reading.saved && <span className="text-amber-600 text-lg">⭐</span>}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(reading.id);
                        }}
                        className="text-red-600 hover:text-red-700 font-medium text-sm"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>

                  {playingAudioId === reading.id && reading.audioUrl && (
                    <div className="mt-4 pt-4 border-t border-slate-200">
                      <audio controls className="w-full" autoPlay>
                        <source src={reading.audioUrl} type="audio/mpeg" />
                      </audio>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-slate-600 mb-4">
                {savedOnly
                  ? "You haven't saved any readings yet."
                  : 'No readings yet. Generate your first reading summary!'}
              </p>
              {savedOnly && (
                <button
                  onClick={() => setSavedOnly(false)}
                  className="text-blue-600 hover:text-blue-700 font-medium"
                >
                  View all readings →
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
