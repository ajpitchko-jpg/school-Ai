'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import ReactMarkdown from 'react-markdown';

interface Subject {
  id: number;
  name: string;
  code: string;
}

interface HomeworkHelp {
  id: number;
  title: string;
  question: string;
  response: string;
  subjectId?: number;
  saved: boolean;
  createdAt: string;
}

export default function HomeworkHelperPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [history, setHistory] = useState<HomeworkHelp[]>([]);
  const [loading, setLoading] = useState(false);
  const [answering, setAnswering] = useState(false);
  const [activeTab, setActiveTab] = useState<'ask' | 'history'>('ask');
  const [formData, setFormData] = useState({
    title: '',
    question: '',
    subjectId: '',
  });
  const [currentResponse, setCurrentResponse] = useState<HomeworkHelp | null>(null);
  const [savedOnly, setSavedOnly] = useState(false);

  useEffect(() => {
    if (!session) {
      router.push('/login');
      return;
    }
    fetchSubjects();
    fetchHistory();
  }, [session, router]);

  const fetchSubjects = async () => {
    try {
      const res = await fetch('/api/subjects');
      const data = await res.json();
      setSubjects(data);
    } catch (error) {
      console.error('Error fetching subjects:', error);
    }
  };

  const fetchHistory = async () => {
    try {
      const res = await fetch('/api/homework-help/history');
      const data = await res.json();
      setHistory(data);
    } catch (error) {
      console.error('Error fetching history:', error);
    }
  };

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title.trim() || !formData.question.trim()) {
      alert('Please fill in both title and question');
      return;
    }

    setAnswering(true);

    try {
      const res = await fetch('/api/homework-help/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formData.title,
          question: formData.question,
          subjectId: formData.subjectId || null,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setCurrentResponse({
          id: data.id,
          title: formData.title,
          question: formData.question,
          response: data.response,
          subjectId: formData.subjectId ? parseInt(formData.subjectId) : undefined,
          saved: false,
          createdAt: new Date().toISOString(),
        });
        setFormData({ title: '', question: '', subjectId: '' });
        setActiveTab('ask');
        // Refresh history
        setTimeout(fetchHistory, 1000);
      } else {
        const error = await res.json();
        alert(error.error || 'Failed to get response');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred. Make sure ANTHROPIC_API_KEY is set in environment.');
    } finally {
      setAnswering(false);
    }
  };

  const handleSave = async (id: number) => {
    try {
      const res = await fetch(`/api/homework-help/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ saved: true }),
      });

      if (res.ok) {
        if (currentResponse?.id === id) {
          setCurrentResponse({ ...currentResponse, saved: true });
        }
        fetchHistory();
      }
    } catch (error) {
      console.error('Error saving:', error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this response?')) return;

    try {
      const res = await fetch(`/api/homework-help/${id}`, { method: 'DELETE' });

      if (res.ok) {
        if (currentResponse?.id === id) {
          setCurrentResponse(null);
        }
        fetchHistory();
      }
    } catch (error) {
      console.error('Error deleting:', error);
    }
  };

  const subjectMap = new Map(subjects.map((s) => [s.id, s]));
  const filteredHistory = savedOnly ? history.filter((h) => h.saved) : history;

  if (!session) {
    return (
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <p className="text-center text-slate-600">Please sign in to use homework helper.</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold text-slate-900 mb-8">🤖 Homework Helper</h1>

      {/* Tabs */}
      <div className="flex gap-4 mb-8">
        <button
          onClick={() => setActiveTab('ask')}
          className={`px-6 py-3 rounded-lg font-semibold transition ${
            activeTab === 'ask'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
          }`}
        >
          ❓ Ask a Question
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`px-6 py-3 rounded-lg font-semibold transition ${
            activeTab === 'history'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
          }`}
        >
          📚 History ({history.length})
        </button>
      </div>

      {/* Ask Tab */}
      {activeTab === 'ask' && (
        <div className="space-y-6">
          {/* Form */}
          <div className="bg-white rounded-lg p-8 shadow-sm border border-slate-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Get Homework Help</h2>
            <form onSubmit={handleAsk} className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Subject (Optional)
                  </label>
                  <select
                    value={formData.subjectId}
                    onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select a subject</option>
                    {subjects.map((subject) => (
                      <option key={subject.id} value={subject.id}>
                        {subject.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Topic/Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g., Quadratic Equations, Photosynthesis"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Your Question *
                </label>
                <textarea
                  required
                  value={formData.question}
                  onChange={(e) => setFormData({ ...formData, question: e.target.value })}
                  rows={6}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Ask your question in detail. The more specific you are, the better the help!"
                />
              </div>

              <button
                type="submit"
                disabled={answering}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-semibold py-3 px-6 rounded-lg transition"
              >
                {answering ? '🔄 Getting Help...' : '✨ Get Help'}
              </button>
            </form>
          </div>

          {/* Current Response */}
          {currentResponse && (
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-8 shadow-sm border border-blue-200">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">{currentResponse.title}</h3>
                  {currentResponse.subjectId && (
                    <p className="text-sm text-slate-600 mt-1">
                      {subjectMap.get(currentResponse.subjectId)?.name}
                    </p>
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleSave(currentResponse.id)}
                    disabled={currentResponse.saved}
                    className="text-amber-600 hover:text-amber-700 font-medium text-sm disabled:text-gray-400"
                  >
                    {currentResponse.saved ? '⭐ Saved' : '☆ Save'}
                  </button>
                  <button
                    onClick={() => {
                      handleDelete(currentResponse.id);
                      setCurrentResponse(null);
                    }}
                    className="text-red-600 hover:text-red-700 font-medium text-sm"
                  >
                    🗑️
                  </button>
                </div>
              </div>

              <div className="mb-6">
                <h4 className="font-semibold text-slate-900 mb-3">Your Question:</h4>
                <p className="text-slate-700 bg-white rounded p-4 border border-slate-200">
                  {currentResponse.question}
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-slate-900 mb-3">💡 Help & Explanation:</h4>
                <div className="bg-white rounded p-6 border border-slate-200 prose prose-sm max-w-none">
                  <ReactMarkdown
                    components={{
                      p: ({ node, ...props }) => <p className="text-slate-700 mb-4" {...props} />,
                      h1: ({ node, ...props }) => (
                        <h1 className="text-2xl font-bold text-slate-900 mt-6 mb-4" {...props} />
                      ),
                      h2: ({ node, ...props }) => (
                        <h2 className="text-xl font-bold text-slate-900 mt-5 mb-3" {...props} />
                      ),
                      h3: ({ node, ...props }) => (
                        <h3 className="text-lg font-bold text-slate-900 mt-4 mb-2" {...props} />
                      ),
                      ul: ({ node, ...props }) => (
                        <ul className="list-disc list-inside text-slate-700 mb-4 space-y-2" {...props} />
                      ),
                      ol: ({ node, ...props }) => (
                        <ol className="list-decimal list-inside text-slate-700 mb-4 space-y-2" {...props} />
                      ),
                      li: ({ node, ...props }) => <li className="text-slate-700" {...props} />,
                      code: ({ node, ...props }) => (
                        <code
                          className="bg-slate-100 px-2 py-1 rounded text-sm font-mono text-red-600"
                          {...props}
                        />
                      ),
                      blockquote: ({ node, ...props }) => (
                        <blockquote
                          className="border-l-4 border-blue-500 pl-4 italic text-slate-700 my-4"
                          {...props}
                        />
                      ),
                    }}
                  >
                    {currentResponse.response}
                  </ReactMarkdown>
                </div>
              </div>

              <p className="text-xs text-slate-600 mt-4">
                Saved on {new Date(currentResponse.createdAt).toLocaleString()}
              </p>
            </div>
          )}

          {/* Tips */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-6">
            <h3 className="font-semibold text-amber-900 mb-3">💡 Tips for Better Help:</h3>
            <ul className="space-y-2 text-sm text-amber-800">
              <li>✓ Be specific - include examples or context</li>
              <li>✓ Explain what you've already tried</li>
              <li>✓ Ask about the "why" not just the answer</li>
              <li>✓ Include relevant formulas or theorems</li>
              <li>✓ Save helpful responses for future reference</li>
            </ul>
          </div>
        </div>
      )}

      {/* History Tab */}
      {activeTab === 'history' && (
        <div className="space-y-6">
          {/* Filter */}
          <div className="flex gap-4">
            <button
              onClick={() => setSavedOnly(false)}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                !savedOnly
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
              }`}
            >
              All ({history.length})
            </button>
            <button
              onClick={() => setSavedOnly(true)}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                savedOnly
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
              }`}
            >
              ⭐ Saved ({history.filter((h) => h.saved).length})
            </button>
          </div>

          {/* History List */}
          {filteredHistory.length > 0 ? (
            <div className="space-y-4">
              {filteredHistory.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-lg p-6 shadow-sm border border-slate-200 hover:shadow-md transition cursor-pointer"
                  onClick={() => {
                    setCurrentResponse(item);
                    setActiveTab('ask');
                  }}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-slate-900">{item.title}</h3>
                      {item.subjectId && (
                        <p className="text-sm text-slate-600 mt-1">
                          📚 {subjectMap.get(item.subjectId)?.name}
                        </p>
                      )}
                      <p className="text-sm text-slate-600 mt-2 line-clamp-2">{item.question}</p>
                      <p className="text-xs text-slate-500 mt-2">
                        {new Date(item.createdAt).toLocaleDateString()} at{' '}
                        {new Date(item.createdAt).toLocaleTimeString()}
                      </p>
                    </div>
                    <div className="flex gap-2 ml-4">
                      {item.saved && <span className="text-amber-600 text-lg">⭐</span>}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(item.id);
                        }}
                        className="text-red-600 hover:text-red-700 font-medium text-sm"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-slate-600 mb-4">
                {savedOnly
                  ? "You haven't saved any responses yet."
                  : "No questions asked yet. Start by asking a question!"}
              </p>
              {savedOnly && (
                <button
                  onClick={() => setSavedOnly(false)}
                  className="text-blue-600 hover:text-blue-700 font-medium"
                >
                  View all responses →
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
