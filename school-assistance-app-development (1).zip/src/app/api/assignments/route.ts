import { db } from '@/db';
import { assignments } from '@/db/schema';
import { NextRequest, NextResponse } from 'next/server';
import { eq, desc, and } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const subjectId = searchParams.get('subjectId');
    const status = searchParams.get('status');

    const conditions: any[] = [];
    
    if (subjectId) {
      conditions.push(eq(assignments.subjectId, parseInt(subjectId)));
    }
    if (status) {
      conditions.push(eq(assignments.status, status));
    }

    const results = conditions.length > 0
      ? await db
          .select()
          .from(assignments)
          .where(and(...conditions))
          .orderBy(desc(assignments.dueDate))
      : await db
          .select()
          .from(assignments)
          .orderBy(desc(assignments.dueDate));
    return NextResponse.json(results);
  } catch (error) {
    console.error('Error fetching assignments:', error);
    return NextResponse.json({ error: 'Failed to fetch assignments' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { subjectId, title, description, dueDate, priority } = body;

    if (!subjectId || !title || !dueDate) {
      return NextResponse.json({ error: 'Required fields missing' }, { status: 400 });
    }

    const result = await db
      .insert(assignments)
      .values({
        subjectId: parseInt(subjectId),
        title,
        description,
        dueDate,
        priority,
        status: 'pending',
      })
      .returning();

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error('Error creating assignment:', error);
    return NextResponse.json({ error: 'Failed to create assignment' }, { status: 500 });
  }
}
