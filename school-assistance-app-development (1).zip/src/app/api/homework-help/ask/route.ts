import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { db } from '@/db';
import { users, homeworkHelp } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { Anthropic } from '@anthropic-ai/sdk';

const client = new Anthropic();

const SYSTEM_PROMPT = `You are an experienced and patient homework helper. Your role is to:

1. **Explain concepts clearly** - Break down complex topics into easy-to-understand parts
2. **Guide not give answers** - Help students learn by asking questions and guiding them toward the solution
3. **Be encouraging** - Maintain a supportive, positive tone
4. **Cover multiple subjects** - Help with Math, Science, History, English, Languages, and more
5. **Adapt to level** - Adjust explanations based on how the student asks (high school, college, etc.)
6. **Provide examples** - Use real-world examples to illustrate concepts
7. **Suggest resources** - Recommend study techniques and resources when helpful

When a student asks a question:
- First understand what they're asking and what they already know
- Provide explanations that help them understand the "why" not just the "what"
- If they ask for a direct answer to homework, gently redirect them to learn the concept
- Use formatting (lists, steps, examples) to make explanations clear
- End by checking if they understand and offering to clarify further

Be warm, encouraging, and remember that students learn best through understanding, not just getting answers.`;

export async function POST(request: NextRequest) {
  try {
    const session = await auth();

    if (!session || !session.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { question, title, subjectId } = body;

    if (!question || !title) {
      return NextResponse.json(
        { error: 'Question and title are required' },
        { status: 400 }
      );
    }

    if (!process.env.ANTHROPIC_API_KEY) {
      return NextResponse.json(
        { error: 'AI service not configured' },
        { status: 500 }
      );
    }

    // Get user from DB
    const userRecord = await db.select().from(users).where(eq(users.email, session.user.email));

    if (!userRecord.length) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const userId = userRecord[0].id;

    // Call Anthropic API
    const message = await client.messages.create({
      model: 'claude-3-5-sonnet-20241022',
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages: [
        {
          role: 'user',
          content: question,
        },
      ],
    });

    const responseText =
      message.content[0].type === 'text' ? message.content[0].text : 'Unable to generate response';

    // Save to database
    const result = await db
      .insert(homeworkHelp)
      .values({
        userId,
        subjectId: subjectId ? parseInt(subjectId) : null,
        title,
        question,
        response: responseText,
        responseTokens: message.usage.output_tokens,
      })
      .returning();

    return NextResponse.json(
      {
        success: true,
        id: result[0].id,
        response: responseText,
        tokensUsed: message.usage.output_tokens,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Error in homework help:', error);

    if (error instanceof Error) {
      if (error.message.includes('API key')) {
        return NextResponse.json(
          { error: 'AI service not properly configured' },
          { status: 500 }
        );
      }
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json(
      { error: 'Failed to get homework help' },
      { status: 500 }
    );
  }
}
