import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { db } from '@/db';
import { users, homeworkHelp } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await auth();

    if (!session || !session.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id } = await params;

    // Get user from DB
    const userRecord = await db.select().from(users).where(eq(users.email, session.user.email));

    if (!userRecord.length) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const userId = userRecord[0].id;

    // Get homework help record (verify ownership)
    const result = await db
      .select()
      .from(homeworkHelp)
      .where(eq(homeworkHelp.id, parseInt(id)));

    if (!result.length || result[0].userId !== userId) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error('Error fetching homework help:', error);
    return NextResponse.json({ error: 'Failed to fetch' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await auth();

    if (!session || !session.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id } = await params;
    const body = await request.json();

    // Get user from DB
    const userRecord = await db.select().from(users).where(eq(users.email, session.user.email));

    if (!userRecord.length) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const userId = userRecord[0].id;

    // Verify ownership
    const existing = await db
      .select()
      .from(homeworkHelp)
      .where(eq(homeworkHelp.id, parseInt(id)));

    if (!existing.length || existing[0].userId !== userId) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }

    const result = await db
      .update(homeworkHelp)
      .set(body)
      .where(eq(homeworkHelp.id, parseInt(id)))
      .returning();

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error('Error updating homework help:', error);
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await auth();

    if (!session || !session.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id } = await params;

    // Get user from DB
    const userRecord = await db.select().from(users).where(eq(users.email, session.user.email));

    if (!userRecord.length) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const userId = userRecord[0].id;

    // Verify ownership
    const existing = await db
      .select()
      .from(homeworkHelp)
      .where(eq(homeworkHelp.id, parseInt(id)));

    if (!existing.length || existing[0].userId !== userId) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }

    const result = await db.delete(homeworkHelp).where(eq(homeworkHelp.id, parseInt(id))).returning();

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting homework help:', error);
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 });
  }
}
