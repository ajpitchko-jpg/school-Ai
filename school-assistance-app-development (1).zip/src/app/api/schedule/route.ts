import { db } from '@/db';
import { schedule } from '@/db/schema';
import { NextRequest, NextResponse } from 'next/server';
import { eq, desc } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const subjectId = searchParams.get('subjectId');

    const results = subjectId
      ? await db
          .select()
          .from(schedule)
          .where(eq(schedule.subjectId, parseInt(subjectId)))
          .orderBy(schedule.date, schedule.startTime)
      : await db.select().from(schedule).orderBy(schedule.date, schedule.startTime);

    return NextResponse.json(results);
  } catch (error) {
    console.error('Error fetching schedule:', error);
    return NextResponse.json({ error: 'Failed to fetch schedule' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { subjectId, title, type, date, startTime, endTime, location, notes: noteContent } = body;

    if (!subjectId || !title || !type || !date || !startTime || !endTime) {
      return NextResponse.json({ error: 'Required fields missing' }, { status: 400 });
    }

    const result = await db
      .insert(schedule)
      .values({
        subjectId: parseInt(subjectId),
        title,
        type,
        date,
        startTime,
        endTime,
        location,
        notes: noteContent,
      })
      .returning();

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error('Error creating schedule:', error);
    return NextResponse.json({ error: 'Failed to create schedule' }, { status: 500 });
  }
}
