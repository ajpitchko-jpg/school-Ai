import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { db } from '@/db';
import { users, readingSummaries } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { Anthropic } from '@anthropic-ai/sdk';
import { OpenAI } from 'openai';
import fs from 'fs';
import path from 'path';

const anthropic = new Anthropic();

// Initialize OpenAI only if API key is available
const getOpenAIClient = () => {
  if (!process.env.OPENAI_API_KEY) {
    return null;
  }
  return new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });
};

export async function POST(request: NextRequest) {
  try {
    const session = await auth();

    if (!session || !session.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { book, chapter, subjectId } = body;

    if (!book || !chapter) {
      return NextResponse.json(
        { error: 'Book and chapter are required' },
        { status: 400 }
      );
    }

    if (!process.env.ANTHROPIC_API_KEY) {
      return NextResponse.json(
        { error: 'AI service not configured' },
        { status: 500 }
      );
    }

    // Get user from DB
    const userRecord = await db.select().from(users).where(eq(users.email, session.user.email));

    if (!userRecord.length) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const userId = userRecord[0].id;

    // Generate summary using Claude
    const summaryMessage = await anthropic.messages.create({
      model: 'claude-3-5-sonnet-20241022',
      max_tokens: 1024,
      messages: [
        {
          role: 'user',
          content: `Create a comprehensive but concise summary of "${chapter}" from the book "${book}". 
          
          Please provide:
          1. Main themes and ideas
          2. Key characters/concepts mentioned
          3. Important events or developments
          4. How it connects to the broader work
          
          Write in a clear, engaging way suitable for students learning about this book.
          Keep it between 300-400 words.`,
        },
      ],
    });

    const summary =
      summaryMessage.content[0].type === 'text'
        ? summaryMessage.content[0].text
        : 'Unable to generate summary';

    // Generate audio from summary using OpenAI TTS
    let audioUrl = null;
    let audioFilename = null;
    let duration = null;

    const openai = getOpenAIClient();
    if (openai) {
      try {
        const mp3 = await openai.audio.speech.create({
          model: 'tts-1-hd',
          voice: 'nova',
          input: summary,
        });

        // Save audio file
        const buffer = Buffer.from(await mp3.arrayBuffer());
        const filename = `reading-${Date.now()}.mp3`;
        const filepath = path.join(process.cwd(), 'public', 'audio', filename);

        // Create audio directory if it doesn't exist
        const audioDir = path.dirname(filepath);
        if (!fs.existsSync(audioDir)) {
          fs.mkdirSync(audioDir, { recursive: true });
        }

        fs.writeFileSync(filepath, buffer);
        audioUrl = `/audio/${filename}`;
        audioFilename = filename;

        // Estimate duration (roughly 150 words per minute for speech)
        const words = summary.split(/\s+/).length;
        duration = Math.ceil((words / 150) * 60);
      } catch (audioError) {
        console.error('Error generating audio:', audioError);
        // Continue without audio
      }
    }

    // Save to database
    const result = await db
      .insert(readingSummaries)
      .values({
        userId,
        subjectId: subjectId ? parseInt(subjectId) : null,
        book,
        chapter,
        summary,
        audioUrl,
        audioFilename,
        duration,
      })
      .returning();

    return NextResponse.json(
      {
        success: true,
        id: result[0].id,
        summary,
        audioUrl,
        duration,
        hasAudio: !!audioUrl,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Error generating reading summary:', error);

    if (error instanceof Error) {
      if (error.message.includes('API key')) {
        return NextResponse.json(
          { error: 'AI service not properly configured' },
          { status: 500 }
        );
      }
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json(
      { error: 'Failed to generate reading summary' },
      { status: 500 }
    );
  }
}
