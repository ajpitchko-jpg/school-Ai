import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { db } from '@/db';
import { users, readingSummaries } from '@/db/schema';
import { eq, desc, and } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    const session = await auth();

    if (!session || !session.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const saved = searchParams.get('saved');
    const subjectId = searchParams.get('subjectId');

    // Get user from DB
    const userRecord = await db.select().from(users).where(eq(users.email, session.user.email));

    if (!userRecord.length) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const userId = userRecord[0].id;

    const conditions: any[] = [eq(readingSummaries.userId, userId)];

    if (saved === 'true') {
      conditions.push(eq(readingSummaries.saved, true));
    }

    if (subjectId) {
      conditions.push(eq(readingSummaries.subjectId, parseInt(subjectId)));
    }

    const results = await db
      .select()
      .from(readingSummaries)
      .where(and(...conditions))
      .orderBy(desc(readingSummaries.createdAt));

    return NextResponse.json(results);
  } catch (error) {
    console.error('Error fetching reading history:', error);
    return NextResponse.json({ error: 'Failed to fetch history' }, { status: 500 });
  }
}
