import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { db } from '@/db';
import { users, subjects, assignments } from '@/db/schema';
import { eq } from 'drizzle-orm';

const CLASSROOM_API = 'https://classroom.googleapis.com/v1';

export async function POST(request: NextRequest) {
  try {
    const session = await auth();

    if (!session || !session.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const accessToken = session.accessToken;
    if (!accessToken) {
      return NextResponse.json({ error: 'No access token' }, { status: 401 });
    }

    // Get user from DB
    const userRecord = await db.select().from(users).where(eq(users.email, session.user.email));

    if (!userRecord.length) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const userId = userRecord[0].id;

    // Fetch courses from Google Classroom
    const coursesRes = await fetch(`${CLASSROOM_API}/courses?pageSize=100`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!coursesRes.ok) {
      return NextResponse.json(
        { error: 'Failed to fetch courses from Google Classroom' },
        { status: coursesRes.status }
      );
    }

    const coursesData = await coursesRes.json();
    const courses = coursesData.courses || [];

    const syncedSubjects = [];

    // Sync each course as a subject
    for (const course of courses) {
      // Check if subject already exists
      const existingSubject = await db
        .select()
        .from(subjects)
        .where(eq(subjects.googleClassroomId, course.id));

      let subjectId: number;

      if (existingSubject.length > 0) {
        // Update existing subject
        await db
          .update(subjects)
          .set({
            name: course.name,
            code: course.courseCode || '',
            teacher: course.ownerIds?.[0] || existingSubject[0].teacher,
            googleClassroomData: course as any,
          })
          .where(eq(subjects.id, existingSubject[0].id));

        subjectId = existingSubject[0].id;
      } else {
        // Create new subject
        const result = await db
          .insert(subjects)
          .values({
            name: course.name,
            code: course.courseCode || course.id,
            teacher: course.ownerIds?.[0] || '',
            userId,
            googleClassroomId: course.id,
            googleClassroomData: course as any,
          })
          .returning();

        subjectId = result[0].id;
      }

      // Fetch coursework (assignments) for this course
      const courseworkRes = await fetch(`${CLASSROOM_API}/courses/${course.id}/courseWork`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      if (courseworkRes.ok) {
        const courseworkData = await courseworkRes.json();
        const coursework = courseworkData.courseWork || [];

        // Sync assignments
        for (const work of coursework) {
          const existingAssignment = await db
            .select()
            .from(assignments)
            .where(eq(assignments.googleClassroomWorkId, work.id));

          const dueDate = work.dueDate
            ? new Date(work.dueDate.year, work.dueDate.month - 1, work.dueDate.day)
            : new Date();

          if (existingAssignment.length > 0) {
            // Update existing assignment
            await db
              .update(assignments)
              .set({
                title: work.title,
                description: work.description || '',
                dueDate: dueDate.toISOString().split('T')[0],
                googleClassroomData: work as any,
              })
              .where(eq(assignments.id, existingAssignment[0].id));
          } else {
            // Create new assignment
            await db.insert(assignments).values({
              subjectId,
              title: work.title,
              description: work.description || '',
              dueDate: dueDate.toISOString().split('T')[0],
              status: 'pending',
              priority: 'medium',
              googleClassroomWorkId: work.id,
              googleClassroomData: work as any,
            });
          }
        }
      }

      syncedSubjects.push({
        id: subjectId,
        name: course.name,
        code: course.courseCode || course.id,
      });
    }

    return NextResponse.json({
      success: true,
      message: `Synced ${syncedSubjects.length} courses from Google Classroom`,
      subjects: syncedSubjects,
    });
  } catch (error) {
    console.error('Error syncing Google Classroom:', error);
    return NextResponse.json(
      { error: 'Failed to sync Google Classroom' },
      { status: 500 }
    );
  }
}
