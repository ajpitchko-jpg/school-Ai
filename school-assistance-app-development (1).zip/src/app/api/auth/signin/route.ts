import { signIn } from '@/lib/auth';

export async function POST() {
  return await signIn('google', { redirectTo: '/dashboard' });
}
