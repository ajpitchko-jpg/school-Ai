import { db } from '@/db';
import { notes } from '@/db/schema';
import { NextRequest, NextResponse } from 'next/server';
import { eq, desc } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const subjectId = searchParams.get('subjectId');

    const results = subjectId
      ? await db
          .select()
          .from(notes)
          .where(eq(notes.subjectId, parseInt(subjectId)))
          .orderBy(desc(notes.createdAt))
      : await db.select().from(notes).orderBy(desc(notes.createdAt));

    return NextResponse.json(results);
  } catch (error) {
    console.error('Error fetching notes:', error);
    return NextResponse.json({ error: 'Failed to fetch notes' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { subjectId, title, content, isImportant } = body;

    if (!subjectId || !title || !content) {
      return NextResponse.json({ error: 'Required fields missing' }, { status: 400 });
    }

    const result = await db
      .insert(notes)
      .values({
        subjectId: parseInt(subjectId),
        title,
        content,
        isImportant: isImportant || false,
      })
      .returning();

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error('Error creating note:', error);
    return NextResponse.json({ error: 'Failed to create note' }, { status: 500 });
  }
}
