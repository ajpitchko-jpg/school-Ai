import { db } from '@/db';
import { grades } from '@/db/schema';
import { NextRequest, NextResponse } from 'next/server';
import { eq, desc } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const subjectId = searchParams.get('subjectId');

    const results = subjectId
      ? await db
          .select()
          .from(grades)
          .where(eq(grades.subjectId, parseInt(subjectId)))
          .orderBy(desc(grades.gradeDate))
      : await db.select().from(grades).orderBy(desc(grades.gradeDate));

    return NextResponse.json(results);
  } catch (error) {
    console.error('Error fetching grades:', error);
    return NextResponse.json({ error: 'Failed to fetch grades' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { subjectId, title, score, maxScore, gradeDate, weight, notes } = body;

    if (!subjectId || !title || !score || !gradeDate) {
      return NextResponse.json({ error: 'Required fields missing' }, { status: 400 });
    }

    const result = await db
      .insert(grades)
      .values({
        subjectId: parseInt(subjectId),
        title,
        score,
        maxScore: maxScore || 100,
        gradeDate,
        weight: weight || 1,
        notes,
      })
      .returning();

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error('Error creating grade:', error);
    return NextResponse.json({ error: 'Failed to create grade' }, { status: 500 });
  }
}
