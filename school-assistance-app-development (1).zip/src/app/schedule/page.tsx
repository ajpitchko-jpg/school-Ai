'use client';

import { useEffect, useState } from 'react';

interface Subject {
  id: number;
  name: string;
  code: string;
}

interface ScheduleItem {
  id: number;
  title: string;
  type: string;
  date: string;
  startTime: string;
  endTime: string;
  location?: string;
  notes?: string;
  subjectId: number;
}

export default function SchedulePage() {
  const [schedules, setSchedules] = useState<ScheduleItem[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    subjectId: '',
    title: '',
    type: 'class',
    date: '',
    startTime: '',
    endTime: '',
    location: '',
    notes: '',
  });
  const [editing, setEditing] = useState<number | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [scheduleRes, subjectsRes] = await Promise.all([
        fetch('/api/schedule'),
        fetch('/api/subjects'),
      ]);

      const scheduleData = await scheduleRes.json();
      const subjectsData = await subjectsRes.json();

      setSchedules(scheduleData);
      setSubjects(subjectsData);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const url = editing ? `/api/schedule/${editing}` : '/api/schedule';
      const method = editing ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        setFormData({
          subjectId: '',
          title: '',
          type: 'class',
          date: '',
          startTime: '',
          endTime: '',
          location: '',
          notes: '',
        });
        setShowForm(false);
        setEditing(null);
        fetchData();
      }
    } catch (error) {
      console.error('Error saving schedule:', error);
    }
  };

  const handleEdit = (item: ScheduleItem) => {
    setFormData({
      subjectId: item.subjectId.toString(),
      title: item.title,
      type: item.type,
      date: item.date,
      startTime: item.startTime,
      endTime: item.endTime,
      location: item.location || '',
      notes: item.notes || '',
    });
    setEditing(item.id);
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    if (confirm('Are you sure you want to delete this schedule item?')) {
      try {
        const res = await fetch(`/api/schedule/${id}`, { method: 'DELETE' });
        if (res.ok) {
          fetchData();
        }
      } catch (error) {
        console.error('Error deleting schedule:', error);
      }
    }
  };

  const subjectMap = new Map(subjects.map((s) => [s.id, s]));

  // Sort by date and time
  const sortedSchedules = [...schedules].sort((a, b) => {
    const dateCompare = a.date.localeCompare(b.date);
    if (dateCompare !== 0) return dateCompare;
    return a.startTime.localeCompare(b.startTime);
  });

  // Group by date
  const groupedSchedules = new Map<string, ScheduleItem[]>();
  sortedSchedules.forEach((item) => {
    if (!groupedSchedules.has(item.date)) {
      groupedSchedules.set(item.date, []);
    }
    groupedSchedules.get(item.date)!.push(item);
  });

  const getTypeEmoji = (type: string) => {
    switch (type) {
      case 'class':
        return '📚';
      case 'exam':
        return '📝';
      case 'lab':
        return '🔬';
      default:
        return '📌';
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold text-slate-900">Schedule</h1>
        <button
          onClick={() => {
            setShowForm(!showForm);
            setEditing(null);
            setFormData({
              subjectId: '',
              title: '',
              type: 'class',
              date: '',
              startTime: '',
              endTime: '',
              location: '',
              notes: '',
            });
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition"
        >
          {showForm ? '❌ Cancel' : '📅 Add Event'}
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-lg p-8 shadow-sm border border-slate-200 mb-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            {editing ? 'Edit Schedule' : 'Add Schedule Event'}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Subject *</label>
                <select
                  required
                  value={formData.subjectId}
                  onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select a subject</option>
                  {subjects.map((subject) => (
                    <option key={subject.id} value={subject.id}>
                      {subject.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="class">Class</option>
                  <option value="exam">Exam</option>
                  <option value="lab">Lab</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Title *</label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="e.g., Calculus Lecture"
              />
            </div>

            <div className="grid grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Date *</label>
                <input
                  type="date"
                  required
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Start Time *</label>
                <input
                  type="time"
                  required
                  value={formData.startTime}
                  onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">End Time *</label>
                <input
                  type="time"
                  required
                  value={formData.endTime}
                  onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Location</label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="e.g., Room 101"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Notes</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Additional notes (optional)"
              />
            </div>

            <div className="flex gap-4">
              <button
                type="submit"
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition"
              >
                {editing ? 'Update Schedule' : 'Add Event'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditing(null);
                }}
                className="flex-1 bg-slate-300 hover:bg-slate-400 text-slate-900 font-semibold py-2 px-6 rounded-lg transition"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <div className="text-center py-12">
          <p className="text-xl text-slate-600">Loading schedule...</p>
        </div>
      ) : Array.from(groupedSchedules.entries()).length > 0 ? (
        <div className="space-y-8">
          {Array.from(groupedSchedules.entries())
            .sort(([dateA], [dateB]) => dateA.localeCompare(dateB))
            .map(([date, items]) => {
              const dateObj = new Date(date + 'T00:00:00');
              const dateStr = dateObj.toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              });

              return (
                <div key={date}>
                  <h2 className="text-2xl font-bold text-slate-900 mb-4">{dateStr}</h2>
                  <div className="space-y-4">
                    {items.map((item) => {
                      const subject = subjectMap.get(item.subjectId);

                      return (
                        <div
                          key={item.id}
                          className="bg-white rounded-lg p-6 shadow-sm border border-slate-200 hover:shadow-md transition"
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-4 flex-1">
                              <div className="text-3xl">{getTypeEmoji(item.type)}</div>
                              <div className="flex-1">
                                <h3 className="text-lg font-semibold text-slate-900">{item.title}</h3>
                                <p className="text-sm text-slate-600 mt-1">
                                  <span className="font-medium">{subject?.name}</span>
                                </p>
                                <div className="flex items-center gap-4 mt-3 text-sm text-slate-600">
                                  <span>🕐 {item.startTime} - {item.endTime}</span>
                                  {item.location && <span>📍 {item.location}</span>}
                                </div>
                                {item.notes && (
                                  <p className="text-sm text-slate-600 mt-3">
                                    <span className="font-medium">Notes:</span> {item.notes}
                                  </p>
                                )}
                              </div>
                            </div>

                            <div className="flex gap-2 ml-4">
                              <button
                                onClick={() => handleEdit(item)}
                                className="text-blue-600 hover:text-blue-700 font-medium text-sm"
                              >
                                ✏️
                              </button>
                              <button
                                onClick={() => handleDelete(item.id)}
                                className="text-red-600 hover:text-red-700 font-medium text-sm"
                              >
                                🗑️
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-xl text-slate-600 mb-4">No schedule events yet. Plan your day!</p>
        </div>
      )}
    </div>
  );
}
