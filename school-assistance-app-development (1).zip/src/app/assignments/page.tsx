'use client';

import { useEffect, useState } from 'react';

interface Subject {
  id: number;
  name: string;
  code: string;
}

interface Assignment {
  id: number;
  title: string;
  description?: string;
  dueDate: string;
  status: string;
  priority: string;
  subjectId: number;
}

export default function AssignmentsPage() {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState<string>('all');
  const [formData, setFormData] = useState({
    subjectId: '',
    title: '',
    description: '',
    dueDate: '',
    priority: 'medium',
  });
  const [editing, setEditing] = useState<number | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [assignmentsRes, subjectsRes] = await Promise.all([
        fetch('/api/assignments'),
        fetch('/api/subjects'),
      ]);

      const assignmentsData = await assignmentsRes.json();
      const subjectsData = await subjectsRes.json();

      setAssignments(assignmentsData);
      setSubjects(subjectsData);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const url = editing ? `/api/assignments/${editing}` : '/api/assignments';
      const method = editing ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        setFormData({
          subjectId: '',
          title: '',
          description: '',
          dueDate: '',
          priority: 'medium',
        });
        setShowForm(false);
        setEditing(null);
        fetchData();
      }
    } catch (error) {
      console.error('Error saving assignment:', error);
    }
  };

  const handleEdit = (assignment: Assignment) => {
    setFormData({
      subjectId: assignment.subjectId.toString(),
      title: assignment.title,
      description: assignment.description || '',
      dueDate: assignment.dueDate,
      priority: assignment.priority,
    });
    setEditing(assignment.id);
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    if (confirm('Are you sure you want to delete this assignment?')) {
      try {
        const res = await fetch(`/api/assignments/${id}`, { method: 'DELETE' });
        if (res.ok) {
          fetchData();
        }
      } catch (error) {
        console.error('Error deleting assignment:', error);
      }
    }
  };

  const handleStatusChange = async (id: number, newStatus: string) => {
    try {
      const res = await fetch(`/api/assignments/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });

      if (res.ok) {
        fetchData();
      }
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const filteredAssignments =
    filter === 'all'
      ? assignments
      : filter === 'pending'
        ? assignments.filter((a) => a.status === 'pending')
        : filter === 'completed'
          ? assignments.filter((a) => a.status === 'completed')
          : assignments.filter((a) => {
              const dueDate = new Date(a.dueDate);
              return dueDate < new Date() && a.status !== 'completed';
            });

  const subjectMap = new Map(subjects.map((s) => [s.id, s]));

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold text-slate-900">Assignments</h1>
        <button
          onClick={() => {
            setShowForm(!showForm);
            setEditing(null);
            setFormData({
              subjectId: '',
              title: '',
              description: '',
              dueDate: '',
              priority: 'medium',
            });
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition"
        >
          {showForm ? '❌ Cancel' : '➕ New Assignment'}
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-lg p-8 shadow-sm border border-slate-200 mb-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            {editing ? 'Edit Assignment' : 'Create New Assignment'}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Subject *</label>
                <select
                  required
                  value={formData.subjectId}
                  onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select a subject</option>
                  {subjects.map((subject) => (
                    <option key={subject.id} value={subject.id}>
                      {subject.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Priority</label>
                <select
                  value={formData.priority}
                  onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Title *</label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Assignment title"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={4}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Assignment details (optional)"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Due Date *</label>
              <input
                type="date"
                required
                value={formData.dueDate}
                onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="flex gap-4">
              <button
                type="submit"
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition"
              >
                {editing ? 'Update Assignment' : 'Create Assignment'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditing(null);
                }}
                className="flex-1 bg-slate-300 hover:bg-slate-400 text-slate-900 font-semibold py-2 px-6 rounded-lg transition"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filter Buttons */}
      <div className="flex gap-4 mb-8">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-2 rounded-lg font-medium transition ${
            filter === 'all'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
          }`}
        >
          All
        </button>
        <button
          onClick={() => setFilter('pending')}
          className={`px-4 py-2 rounded-lg font-medium transition ${
            filter === 'pending'
              ? 'bg-orange-600 text-white'
              : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
          }`}
        >
          Pending
        </button>
        <button
          onClick={() => setFilter('completed')}
          className={`px-4 py-2 rounded-lg font-medium transition ${
            filter === 'completed'
              ? 'bg-green-600 text-white'
              : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
          }`}
        >
          Completed
        </button>
        <button
          onClick={() => setFilter('overdue')}
          className={`px-4 py-2 rounded-lg font-medium transition ${
            filter === 'overdue'
              ? 'bg-red-600 text-white'
              : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
          }`}
        >
          Overdue
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <p className="text-xl text-slate-600">Loading assignments...</p>
        </div>
      ) : filteredAssignments.length > 0 ? (
        <div className="space-y-4">
          {filteredAssignments.map((assignment) => {
            const subject = subjectMap.get(assignment.subjectId);
            const dueDate = new Date(assignment.dueDate);
            const today = new Date();
            const isOverdue = dueDate < today && assignment.status !== 'completed';
            const daysUntilDue = Math.ceil(
              (dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)
            );

            return (
              <div
                key={assignment.id}
                className="bg-white rounded-lg p-6 shadow-sm border border-slate-200 hover:shadow-md transition"
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-slate-900">{assignment.title}</h3>
                    {assignment.description && (
                      <p className="text-sm text-slate-600 mt-2">{assignment.description}</p>
                    )}
                    <p className="text-sm text-slate-600 mt-2">
                      <span className="font-medium">Subject:</span> {subject?.name}
                    </p>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-sm font-medium text-slate-900">
                        {dueDate.toLocaleDateString()}
                      </div>
                      <div className={`text-xs font-semibold ${isOverdue ? 'text-red-600' : 'text-slate-600'}`}>
                        {isOverdue ? 'Overdue' : daysUntilDue > 0 ? `${daysUntilDue} days left` : 'Today'}
                      </div>
                    </div>

                    <span
                      className={`px-3 py-1 text-xs font-semibold rounded-full ${
                        assignment.priority === 'high'
                          ? 'bg-red-100 text-red-700'
                          : assignment.priority === 'medium'
                            ? 'bg-yellow-100 text-yellow-700'
                            : 'bg-green-100 text-green-700'
                      }`}
                    >
                      {assignment.priority.charAt(0).toUpperCase() + assignment.priority.slice(1)}
                    </span>

                    <span
                      className={`px-3 py-1 text-xs font-semibold rounded-full ${
                        assignment.status === 'completed'
                          ? 'bg-green-100 text-green-700'
                          : assignment.status === 'pending'
                            ? 'bg-blue-100 text-blue-700'
                            : 'bg-orange-100 text-orange-700'
                      }`}
                    >
                      {assignment.status.charAt(0).toUpperCase() + assignment.status.slice(1)}
                    </span>
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => handleStatusChange(assignment.id, 'completed')}
                    disabled={assignment.status === 'completed'}
                    className="text-green-600 hover:text-green-700 font-medium text-sm disabled:text-gray-400"
                  >
                    ✓ Mark Done
                  </button>
                  <button
                    onClick={() => handleEdit(assignment)}
                    className="text-blue-600 hover:text-blue-700 font-medium text-sm"
                  >
                    ✏️ Edit
                  </button>
                  <button
                    onClick={() => handleDelete(assignment.id)}
                    className="text-red-600 hover:text-red-700 font-medium text-sm"
                  >
                    🗑️ Delete
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-xl text-slate-600 mb-4">No assignments found.</p>
        </div>
      )}
    </div>
  );
}
