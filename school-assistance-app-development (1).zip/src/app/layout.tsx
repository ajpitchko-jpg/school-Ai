import type { Metadata } from 'next';
import './globals.css';
import Link from 'next/link';
import Providers from '@/components/Providers';
import UserMenu from '@/components/UserMenu';

export const metadata: Metadata = {
  title: 'School Helper - Your Academic Assistant',
  description: 'Manage assignments, grades, notes, and schedule',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-gradient-to-br from-slate-50 to-slate-100">
        <Providers>
          <div className="flex min-h-screen flex-col">
            {/* Navigation */}
            <nav className="border-b border-slate-200 bg-white shadow-sm">
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="flex h-16 justify-between items-center">
                  <Link href="/" className="text-2xl font-bold text-blue-600">
                    📚 School Helper
                  </Link>
                  <div className="flex gap-8 items-center">
                    <Link href="/" className="text-slate-600 hover:text-blue-600 font-medium">
                      Dashboard
                    </Link>
                    <Link href="/subjects" className="text-slate-600 hover:text-blue-600 font-medium">
                      Subjects
                    </Link>
                    <Link href="/assignments" className="text-slate-600 hover:text-blue-600 font-medium">
                      Assignments
                    </Link>
                    <Link href="/grades" className="text-slate-600 hover:text-blue-600 font-medium">
                      Grades
                    </Link>
                    <Link href="/notes" className="text-slate-600 hover:text-blue-600 font-medium">
                      Notes
                    </Link>
                    <Link href="/schedule" className="text-slate-600 hover:text-blue-600 font-medium">
                      Schedule
                    </Link>
                    <Link href="/homework-helper" className="text-slate-600 hover:text-blue-600 font-medium">
                      🤖 Helper
                    </Link>
                    <Link href="/reading" className="text-slate-600 hover:text-blue-600 font-medium">
                      📚 Reading
                    </Link>
                    <UserMenu />
                  </div>
                </div>
              </div>
            </nav>

            {/* Main Content */}
            <main className="flex-1">
              {children}
            </main>

            {/* Footer */}
            <footer className="border-t border-slate-200 bg-white py-8">
              <div className="mx-auto max-w-7xl px-4 text-center text-slate-600">
                <p>&copy; 2024 School Helper. Keep up with your studies! 🎓</p>
              </div>
            </footer>
          </div>
        </Providers>
      </body>
    </html>
  );
}
