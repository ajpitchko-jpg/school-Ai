'use client';

import { useEffect, useState } from 'react';

interface Subject {
  id: number;
  name: string;
  code: string;
}

interface Note {
  id: number;
  title: string;
  content: string;
  isImportant: boolean;
  subjectId: number;
  createdAt: string;
  updatedAt: string;
}

export default function NotesPage() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    subjectId: '',
    title: '',
    content: '',
    isImportant: false,
  });
  const [editing, setEditing] = useState<number | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [notesRes, subjectsRes] = await Promise.all([
        fetch('/api/notes'),
        fetch('/api/subjects'),
      ]);

      const notesData = await notesRes.json();
      const subjectsData = await subjectsRes.json();

      setNotes(notesData);
      setSubjects(subjectsData);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const url = editing ? `/api/notes/${editing}` : '/api/notes';
      const method = editing ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        setFormData({
          subjectId: '',
          title: '',
          content: '',
          isImportant: false,
        });
        setShowForm(false);
        setEditing(null);
        fetchData();
      }
    } catch (error) {
      console.error('Error saving note:', error);
    }
  };

  const handleEdit = (note: Note) => {
    setFormData({
      subjectId: note.subjectId.toString(),
      title: note.title,
      content: note.content,
      isImportant: note.isImportant,
    });
    setEditing(note.id);
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    if (confirm('Are you sure you want to delete this note?')) {
      try {
        const res = await fetch(`/api/notes/${id}`, { method: 'DELETE' });
        if (res.ok) {
          fetchData();
        }
      } catch (error) {
        console.error('Error deleting note:', error);
      }
    }
  };

  const subjectMap = new Map(subjects.map((s) => [s.id, s]));
  const filteredNotes = selectedSubject
    ? notes.filter((n) => n.subjectId === selectedSubject)
    : notes;

  const importantNotes = filteredNotes.filter((n) => n.isImportant);
  const regularNotes = filteredNotes.filter((n) => !n.isImportant);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold text-slate-900">Study Notes</h1>
        <button
          onClick={() => {
            setShowForm(!showForm);
            setEditing(null);
            setFormData({
              subjectId: '',
              title: '',
              content: '',
              isImportant: false,
            });
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition"
        >
          {showForm ? '❌ Cancel' : '📝 New Note'}
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-lg p-8 shadow-sm border border-slate-200 mb-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            {editing ? 'Edit Note' : 'Create New Note'}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Subject *</label>
                <select
                  required
                  value={formData.subjectId}
                  onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select a subject</option>
                  {subjects.map((subject) => (
                    <option key={subject.id} value={subject.id}>
                      {subject.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-end">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isImportant}
                    onChange={(e) => setFormData({ ...formData, isImportant: e.target.checked })}
                    className="w-5 h-5 rounded"
                  />
                  <span className="text-sm font-medium text-slate-700">⭐ Mark as Important</span>
                </label>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Title *</label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Note title"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Content *</label>
              <textarea
                required
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                rows={8}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                placeholder="Write your notes here..."
              />
            </div>

            <div className="flex gap-4">
              <button
                type="submit"
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition"
              >
                {editing ? 'Update Note' : 'Create Note'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditing(null);
                }}
                className="flex-1 bg-slate-300 hover:bg-slate-400 text-slate-900 font-semibold py-2 px-6 rounded-lg transition"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Subject Filter */}
      <div className="flex gap-2 mb-8 flex-wrap">
        <button
          onClick={() => setSelectedSubject(null)}
          className={`px-4 py-2 rounded-lg font-medium transition ${
            selectedSubject === null
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
          }`}
        >
          All Notes
        </button>
        {subjects.map((subject) => {
          const subjectNoteCount = notes.filter((n) => n.subjectId === subject.id).length;
          return (
            <button
              key={subject.id}
              onClick={() => setSelectedSubject(subject.id)}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                selectedSubject === subject.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
              }`}
            >
              {subject.code} ({subjectNoteCount})
            </button>
          );
        })}
      </div>

      {loading ? (
        <div className="text-center py-12">
          <p className="text-xl text-slate-600">Loading notes...</p>
        </div>
      ) : (
        <div className="space-y-8">
          {/* Important Notes */}
          {importantNotes.length > 0 && (
            <div>
              <h2 className="text-2xl font-bold text-slate-900 mb-4">⭐ Important Notes</h2>
              <div className="space-y-4">
                {importantNotes.map((note) => {
                  const subject = subjectMap.get(note.subjectId);
                  return (
                    <div
                      key={note.id}
                      className="bg-yellow-50 rounded-lg p-6 shadow-sm border border-yellow-200 hover:shadow-md transition"
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-slate-900">{note.title}</h3>
                          <p className="text-sm text-slate-600 mt-1">
                            <span className="font-medium">{subject?.name}</span>
                          </p>
                          <p className="text-sm text-slate-600 mt-2 whitespace-pre-wrap break-words">
                            {note.content}
                          </p>
                        </div>

                        <div className="flex gap-2 ml-4">
                          <button
                            onClick={() => handleEdit(note)}
                            className="text-blue-600 hover:text-blue-700 font-medium text-sm"
                          >
                            ✏️
                          </button>
                          <button
                            onClick={() => handleDelete(note.id)}
                            className="text-red-600 hover:text-red-700 font-medium text-sm"
                          >
                            🗑️
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Regular Notes */}
          {regularNotes.length > 0 && (
            <div>
              {importantNotes.length > 0 && <h2 className="text-2xl font-bold text-slate-900 mb-4">Other Notes</h2>}
              <div className="space-y-4">
                {regularNotes.map((note) => {
                  const subject = subjectMap.get(note.subjectId);
                  return (
                    <div
                      key={note.id}
                      className="bg-white rounded-lg p-6 shadow-sm border border-slate-200 hover:shadow-md transition"
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-slate-900">{note.title}</h3>
                          <p className="text-sm text-slate-600 mt-1">
                            <span className="font-medium">{subject?.name}</span>
                          </p>
                          <p className="text-sm text-slate-600 mt-2 whitespace-pre-wrap break-words">
                            {note.content}
                          </p>
                        </div>

                        <div className="flex gap-2 ml-4">
                          <button
                            onClick={() => handleEdit(note)}
                            className="text-blue-600 hover:text-blue-700 font-medium text-sm"
                          >
                            ✏️
                          </button>
                          <button
                            onClick={() => handleDelete(note.id)}
                            className="text-red-600 hover:text-red-700 font-medium text-sm"
                          >
                            🗑️
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {filteredNotes.length === 0 && (
            <div className="text-center py-12">
              <p className="text-xl text-slate-600 mb-4">No notes yet. Create your first note!</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
