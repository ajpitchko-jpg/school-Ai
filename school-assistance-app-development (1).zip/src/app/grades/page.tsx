'use client';

import { useEffect, useState } from 'react';

interface Subject {
  id: number;
  name: string;
  code: string;
}

interface Grade {
  id: number;
  title: string;
  score: string;
  maxScore: string;
  gradeDate: string;
  subjectId: number;
  notes?: string;
}

export default function GradesPage() {
  const [grades, setGrades] = useState<Grade[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    subjectId: '',
    title: '',
    score: '',
    maxScore: '100',
    gradeDate: new Date().toISOString().split('T')[0],
    notes: '',
  });
  const [editing, setEditing] = useState<number | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [gradesRes, subjectsRes] = await Promise.all([
        fetch('/api/grades'),
        fetch('/api/subjects'),
      ]);

      const gradesData = await gradesRes.json();
      const subjectsData = await subjectsRes.json();

      setGrades(gradesData);
      setSubjects(subjectsData);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const url = editing ? `/api/grades/${editing}` : '/api/grades';
      const method = editing ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        setFormData({
          subjectId: '',
          title: '',
          score: '',
          maxScore: '100',
          gradeDate: new Date().toISOString().split('T')[0],
          notes: '',
        });
        setShowForm(false);
        setEditing(null);
        fetchData();
      }
    } catch (error) {
      console.error('Error saving grade:', error);
    }
  };

  const handleEdit = (grade: Grade) => {
    setFormData({
      subjectId: grade.subjectId.toString(),
      title: grade.title,
      score: grade.score,
      maxScore: grade.maxScore,
      gradeDate: grade.gradeDate,
      notes: grade.notes || '',
    });
    setEditing(grade.id);
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    if (confirm('Are you sure you want to delete this grade?')) {
      try {
        const res = await fetch(`/api/grades/${id}`, { method: 'DELETE' });
        if (res.ok) {
          fetchData();
        }
      } catch (error) {
        console.error('Error deleting grade:', error);
      }
    }
  };

  const subjectMap = new Map(subjects.map((s) => [s.id, s]));

  // Calculate statistics
  const overallAverage =
    grades.length > 0
      ? (grades.reduce((sum, g) => sum + (parseFloat(g.score) / parseFloat(g.maxScore)) * 100, 0) / grades.length).toFixed(1)
      : 'N/A';

  const subjectStats = subjects.map((subject) => {
    const subjectGrades = grades.filter((g) => g.subjectId === subject.id);
    const average =
      subjectGrades.length > 0
        ? (subjectGrades.reduce((sum, g) => sum + (parseFloat(g.score) / parseFloat(g.maxScore)) * 100, 0) / subjectGrades.length).toFixed(1)
        : 'N/A';

    return { subject, average, count: subjectGrades.length };
  });

  const filteredGrades = selectedSubject
    ? grades.filter((g) => g.subjectId === selectedSubject)
    : grades;

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold text-slate-900">Grades</h1>
        <button
          onClick={() => {
            setShowForm(!showForm);
            setEditing(null);
            setFormData({
              subjectId: '',
              title: '',
              score: '',
              maxScore: '100',
              gradeDate: new Date().toISOString().split('T')[0],
              notes: '',
            });
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition"
        >
          {showForm ? '❌ Cancel' : '➕ New Grade'}
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-lg p-8 shadow-sm border border-slate-200 mb-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            {editing ? 'Edit Grade' : 'Record New Grade'}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Subject *</label>
                <select
                  required
                  value={formData.subjectId}
                  onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select a subject</option>
                  {subjects.map((subject) => (
                    <option key={subject.id} value={subject.id}>
                      {subject.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Grade Date *</label>
                <input
                  type="date"
                  required
                  value={formData.gradeDate}
                  onChange={(e) => setFormData({ ...formData, gradeDate: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Assessment Title *</label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="e.g., Midterm Exam, Quiz 1, Project"
              />
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Score *</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={formData.score}
                  onChange={(e) => setFormData({ ...formData, score: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Your score"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Max Score</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.maxScore}
                  onChange={(e) => setFormData({ ...formData, maxScore: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Notes</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Additional comments (optional)"
              />
            </div>

            <div className="flex gap-4">
              <button
                type="submit"
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition"
              >
                {editing ? 'Update Grade' : 'Record Grade'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditing(null);
                }}
                className="flex-1 bg-slate-300 hover:bg-slate-400 text-slate-900 font-semibold py-2 px-6 rounded-lg transition"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
          <div className="text-sm text-slate-600 font-medium">Overall Average</div>
          <div className="text-3xl font-bold text-green-600 mt-2">{overallAverage}%</div>
          <div className="text-xs text-slate-600 mt-2">{grades.length} grades recorded</div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
          <div className="text-sm text-slate-600 font-medium">Subject with Best Average</div>
          <div className="mt-4">
            {subjectStats.filter((s) => s.count > 0).sort((a, b) => parseFloat(b.average) - parseFloat(a.average))[0] ? (
              <>
                <div className="font-bold text-slate-900">
                  {subjectStats.filter((s) => s.count > 0).sort((a, b) => parseFloat(b.average) - parseFloat(a.average))[0].subject.name}
                </div>
                <div className="text-2xl font-bold text-blue-600 mt-1">
                  {subjectStats.filter((s) => s.count > 0).sort((a, b) => parseFloat(b.average) - parseFloat(a.average))[0].average}%
                </div>
              </>
            ) : (
              <div className="text-slate-600">No grades yet</div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
          <div className="text-sm text-slate-600 font-medium">Subjects</div>
          <div className="text-3xl font-bold text-purple-600 mt-2">{subjectStats.filter((s) => s.count > 0).length}</div>
          <div className="text-xs text-slate-600 mt-2">with grades</div>
        </div>
      </div>

      {/* Subject Filter */}
      <div className="flex gap-2 mb-8 flex-wrap">
        <button
          onClick={() => setSelectedSubject(null)}
          className={`px-4 py-2 rounded-lg font-medium transition ${
            selectedSubject === null
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
          }`}
        >
          All Subjects
        </button>
        {subjects.map((subject) => {
          const subjectGradeCount = grades.filter((g) => g.subjectId === subject.id).length;
          return (
            <button
              key={subject.id}
              onClick={() => setSelectedSubject(subject.id)}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                selectedSubject === subject.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
              }`}
            >
              {subject.code} ({subjectGradeCount})
            </button>
          );
        })}
      </div>

      {loading ? (
        <div className="text-center py-12">
          <p className="text-xl text-slate-600">Loading grades...</p>
        </div>
      ) : filteredGrades.length > 0 ? (
        <div className="space-y-4">
          {filteredGrades
            .sort((a, b) => new Date(b.gradeDate).getTime() - new Date(a.gradeDate).getTime())
            .map((grade) => {
              const subject = subjectMap.get(grade.subjectId);
              const percentage = ((parseFloat(grade.score) / parseFloat(grade.maxScore)) * 100).toFixed(1);

              return (
                <div
                  key={grade.id}
                  className="bg-white rounded-lg p-6 shadow-sm border border-slate-200 hover:shadow-md transition"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-slate-900">{grade.title}</h3>
                      <p className="text-sm text-slate-600 mt-1">
                        <span className="font-medium">{subject?.name}</span> · {new Date(grade.gradeDate).toLocaleDateString()}
                      </p>
                      {grade.notes && <p className="text-sm text-slate-600 mt-2">{grade.notes}</p>}
                    </div>

                    <div className="text-right ml-4">
                      <div className="text-3xl font-bold text-blue-600">{percentage}%</div>
                      <div className="text-sm text-slate-600">
                        {grade.score} / {grade.maxScore}
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2 mt-4">
                    <button
                      onClick={() => handleEdit(grade)}
                      className="text-blue-600 hover:text-blue-700 font-medium text-sm"
                    >
                      ✏️ Edit
                    </button>
                    <button
                      onClick={() => handleDelete(grade.id)}
                      className="text-red-600 hover:text-red-700 font-medium text-sm"
                    >
                      🗑️ Delete
                    </button>
                  </div>
                </div>
              );
            })}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-xl text-slate-600 mb-4">No grades recorded yet.</p>
        </div>
      )}
    </div>
  );
}
