'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSession } from 'next-auth/react';
import GoogleClassroomSync from '@/components/GoogleClassroomSync';

interface Subject {
  id: number;
  name: string;
  code: string;
  teacher?: string;
}

interface Assignment {
  id: number;
  title: string;
  dueDate: string;
  status: string;
  priority: string;
  subjectId: number;
}

interface Grade {
  id: number;
  title: string;
  score: string;
  maxScore: string;
  subjectId: number;
}

export default function Dashboard() {
  const { data: session } = useSession();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [subjectsRes, assignmentsRes, gradesRes] = await Promise.all([
          fetch('/api/subjects'),
          fetch('/api/assignments'),
          fetch('/api/grades'),
        ]);

        const subjectsData = await subjectsRes.json();
        const assignmentsData = await assignmentsRes.json();
        const gradesData = await gradesRes.json();

        setSubjects(subjectsData);
        setAssignments(assignmentsData);
        setGrades(gradesData);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const upcomingAssignments = assignments
    .filter((a) => a.status !== 'completed')
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    .slice(0, 5);

  const subjectMap = new Map(subjects.map((s) => [s.id, s]));
  const averageGrade =
    grades.length > 0
      ? (
          grades.reduce((sum, g) => sum + (parseFloat(g.score) / parseFloat(g.maxScore)) * 100, 0) /
          grades.length
        ).toFixed(1)
      : 'N/A';

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <div className="mb-12">
        <h1 className="text-4xl font-bold text-slate-900">Welcome to School Helper</h1>
        <p className="mt-2 text-lg text-slate-600">Your personal academic companion</p>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <p className="text-xl text-slate-600">Loading your data...</p>
        </div>
      ) : (
        <div className="space-y-12">
          {/* Google Classroom Sync */}
          {session && <GoogleClassroomSync />}

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
              <div className="text-sm text-slate-600 font-medium">Subjects</div>
              <div className="text-3xl font-bold text-blue-600 mt-2">{subjects.length}</div>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
              <div className="text-sm text-slate-600 font-medium">Pending Assignments</div>
              <div className="text-3xl font-bold text-orange-600 mt-2">
                {assignments.filter((a) => a.status === 'pending').length}
              </div>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
              <div className="text-sm text-slate-600 font-medium">Average Grade</div>
              <div className="text-3xl font-bold text-green-600 mt-2">{averageGrade}%</div>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
              <div className="text-sm text-slate-600 font-medium">Total Grades</div>
              <div className="text-3xl font-bold text-purple-600 mt-2">{grades.length}</div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-lg p-8 shadow-sm border border-slate-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Quick Actions</h2>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <Link
                href="/subjects"
                className="flex items-center justify-center gap-2 bg-blue-50 hover:bg-blue-100 text-blue-600 font-medium py-3 px-4 rounded-lg transition"
              >
                📖 Manage Subjects
              </Link>
              <Link
                href="/assignments"
                className="flex items-center justify-center gap-2 bg-orange-50 hover:bg-orange-100 text-orange-600 font-medium py-3 px-4 rounded-lg transition"
              >
                ✅ Assignments
              </Link>
              <Link
                href="/grades"
                className="flex items-center justify-center gap-2 bg-green-50 hover:bg-green-100 text-green-600 font-medium py-3 px-4 rounded-lg transition"
              >
                📊 Grades
              </Link>
              <Link
                href="/notes"
                className="flex items-center justify-center gap-2 bg-purple-50 hover:bg-purple-100 text-purple-600 font-medium py-3 px-4 rounded-lg transition"
              >
                📝 Notes
              </Link>
              <Link
                href="/homework-helper"
                className="flex items-center justify-center gap-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 font-medium py-3 px-4 rounded-lg transition"
              >
                🤖 AI Helper
              </Link>
              <Link
                href="/reading"
                className="flex items-center justify-center gap-2 bg-rose-50 hover:bg-rose-100 text-rose-600 font-medium py-3 px-4 rounded-lg transition"
              >
                📚 Reading
              </Link>
            </div>
          </div>

          {/* Upcoming Assignments */}
          <div className="bg-white rounded-lg p-8 shadow-sm border border-slate-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Upcoming Assignments</h2>
            {upcomingAssignments.length > 0 ? (
              <div className="space-y-4">
                {upcomingAssignments.map((assignment) => {
                  const subject = subjectMap.get(assignment.subjectId);
                  const daysUntilDue = Math.ceil(
                    (new Date(assignment.dueDate).getTime() - new Date().getTime()) /
                      (1000 * 60 * 60 * 24)
                  );

                  return (
                    <div
                      key={assignment.id}
                      className="flex justify-between items-center p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition"
                    >
                      <div className="flex-1">
                        <h3 className="font-semibold text-slate-900">{assignment.title}</h3>
                        <p className="text-sm text-slate-600">{subject?.name || 'Unknown Subject'}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="text-sm font-medium text-slate-900">
                            {new Date(assignment.dueDate).toLocaleDateString()}
                          </div>
                          <div className={`text-xs font-semibold ${daysUntilDue <= 3 ? 'text-red-600' : 'text-slate-600'}`}>
                            {daysUntilDue > 0 ? `${daysUntilDue} days left` : 'Overdue'}
                          </div>
                        </div>
                        <span
                          className={`px-3 py-1 text-xs font-semibold rounded-full ${
                            assignment.priority === 'high'
                              ? 'bg-red-100 text-red-700'
                              : assignment.priority === 'medium'
                                ? 'bg-yellow-100 text-yellow-700'
                                : 'bg-green-100 text-green-700'
                          }`}
                        >
                          {assignment.priority.charAt(0).toUpperCase() + assignment.priority.slice(1)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-slate-600">No pending assignments. Great job! 🎉</p>
            )}
          </div>

          {/* Subjects Overview */}
          {subjects.length > 0 && (
            <div className="bg-white rounded-lg p-8 shadow-sm border border-slate-200">
              <h2 className="text-2xl font-bold text-slate-900 mb-6">Your Subjects</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {subjects.map((subject) => {
                  const subjectAssignments = assignments.filter((a) => a.subjectId === subject.id);
                  const subjectGrades = grades.filter((g) => g.subjectId === subject.id);
                  const avgGrade =
                    subjectGrades.length > 0
                      ? (
                          subjectGrades.reduce(
                            (sum, g) => sum + (parseFloat(g.score) / parseFloat(g.maxScore)) * 100,
                            0
                          ) / subjectGrades.length
                        ).toFixed(1)
                      : 'N/A';

                  return (
                    <div
                      key={subject.id}
                      className="p-6 border border-slate-200 rounded-lg hover:shadow-md transition"
                    >
                      <h3 className="text-lg font-semibold text-slate-900">{subject.name}</h3>
                      <p className="text-sm text-slate-600 mt-1">{subject.code}</p>
                      {subject.teacher && (
                        <p className="text-sm text-slate-600">👨‍🏫 {subject.teacher}</p>
                      )}
                      <div className="mt-4 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-600">Assignments:</span>
                          <span className="font-semibold">{subjectAssignments.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Average Grade:</span>
                          <span className="font-semibold text-green-600">{avgGrade}%</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
