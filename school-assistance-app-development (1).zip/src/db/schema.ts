import { pgTable, serial, text, timestamp, numeric, varchar, boolean, date, integer, jsonb } from 'drizzle-orm/pg-core';

// Users table for authentication
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  name: varchar('name', { length: 255 }),
  googleId: varchar('google_id', { length: 255 }).unique(),
  googleAccessToken: text('google_access_token'),
  googleRefreshToken: text('google_refresh_token'),
  googleTokenExpiry: timestamp('google_token_expiry'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Subjects table
export const subjects = pgTable('subjects', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  code: varchar('code', { length: 50 }).notNull(),
  teacher: varchar('teacher', { length: 255 }),
  room: varchar('room', { length: 50 }),
  userId: integer('user_id').references(() => users.id),
  googleClassroomId: varchar('google_classroom_id', { length: 255 }),
  googleClassroomData: jsonb('google_classroom_data'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Assignments table
export const assignments = pgTable('assignments', {
  id: serial('id').primaryKey(),
  subjectId: integer('subject_id').references(() => subjects.id).notNull(),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description'),
  dueDate: date('due_date').notNull(),
  status: varchar('status', { length: 50 }).default('pending'), // pending, completed, overdue
  completedAt: timestamp('completed_at'),
  priority: varchar('priority', { length: 50 }).default('medium'), // low, medium, high
  googleClassroomWorkId: varchar('google_classroom_work_id', { length: 255 }),
  googleClassroomData: jsonb('google_classroom_data'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Grades table
export const grades = pgTable('grades', {
  id: serial('id').primaryKey(),
  subjectId: integer('subject_id').references(() => subjects.id).notNull(),
  assignmentId: integer('assignment_id').references(() => assignments.id),
  title: varchar('title', { length: 255 }).notNull(),
  score: numeric('score', { precision: 5, scale: 2 }).notNull(),
  maxScore: numeric('max_score', { precision: 5, scale: 2 }).default('100'),
  weight: numeric('weight', { precision: 5, scale: 2 }).default('1'), // For calculating weighted GPA
  gradeDate: date('grade_date').notNull(),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Study notes table
export const notes = pgTable('notes', {
  id: serial('id').primaryKey(),
  subjectId: integer('subject_id').references(() => subjects.id).notNull(),
  title: varchar('title', { length: 255 }).notNull(),
  content: text('content').notNull(),
  isImportant: boolean('is_important').default(false),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Schedule table (for classes and exams)
export const schedule = pgTable('schedule', {
  id: serial('id').primaryKey(),
  subjectId: integer('subject_id').references(() => subjects.id).notNull(),
  title: varchar('title', { length: 255 }).notNull(),
  type: varchar('type', { length: 50 }).notNull(), // class, exam, lab, other
  date: date('date').notNull(),
  startTime: varchar('start_time', { length: 10 }).notNull(),
  endTime: varchar('end_time', { length: 10 }).notNull(),
  location: varchar('location', { length: 255 }),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Homework Help conversations
export const homeworkHelp = pgTable('homework_help', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  subjectId: integer('subject_id').references(() => subjects.id),
  title: varchar('title', { length: 255 }).notNull(),
  question: text('question').notNull(),
  response: text('response').notNull(),
  responseTokens: integer('response_tokens'),
  helpful: boolean('helpful'),
  saved: boolean('saved').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// Reading summaries with audio
export const readingSummaries = pgTable('reading_summaries', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  subjectId: integer('subject_id').references(() => subjects.id),
  book: varchar('book', { length: 255 }).notNull(),
  chapter: varchar('chapter', { length: 255 }).notNull(),
  summary: text('summary').notNull(),
  audioUrl: text('audio_url'),
  audioFilename: varchar('audio_filename', { length: 255 }),
  duration: integer('duration'), // Duration in seconds
  saved: boolean('saved').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});
