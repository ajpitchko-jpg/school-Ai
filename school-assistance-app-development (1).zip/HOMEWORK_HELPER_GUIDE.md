# 🤖 Homework Helper - Complete Guide

The Homework Helper is an AI-powered feature that provides personalized homework assistance for all subjects. It uses Claude AI to give explanations, guidance, and help students understand difficult concepts.

## Features

### 📚 Core Functionality
- ✅ **Ask Questions** - Get help on homework and concepts
- ✅ **Smart Explanations** - AI provides clear, student-friendly explanations
- ✅ **Subject Tracking** - Link questions to your subjects
- ✅ **Save Responses** - Bookmark helpful answers for future reference
- ✅ **History Tracking** - Access all past questions and responses
- ✅ **Response Management** - Delete or organize your responses

### 🎯 What It Can Help With
- Math (Algebra, Geometry, Calculus, Statistics)
- Sciences (Physics, Chemistry, Biology)
- History & Social Studies
- Languages (Grammar, vocabulary, translation concepts)
- Literature & English
- Computer Science
- Economics & Business
- And much more!

## Setup

### Prerequisites
1. **Anthropic Account** - Create account at [console.anthropic.com](https://console.anthropic.com)
2. **API Key** - Get your API key from the console
3. **Signed in to School Helper** - Must be logged in to use homework helper

### Step 1: Get Anthropic API Key

1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Sign up or log in
3. Navigate to "API Keys"
4. Click "Create Key"
5. Copy the generated key

### Step 2: Add to Environment

1. Open `.env.local` in your project root
2. Add:
```env
ANTHROPIC_API_KEY=your_anthropic_api_key_here
```

3. Restart your development server:
```bash
npm run dev
```

### Step 3: Access Homework Helper

1. Sign in to School Helper
2. Click "🤖 Helper" in navigation
3. Start asking questions!

## How to Use

### Asking a Question

1. **Go to "Ask a Question" tab**
   - This is the default tab when you open Homework Helper

2. **Fill in the form:**
   - **Subject** (Optional) - Select the related subject from your courses
   - **Topic/Title** - Brief title of what you're asking about
     - Examples: "Quadratic Equations", "Photosynthesis", "Spanish Subjunctive"
   - **Your Question** - Detailed question or problem

3. **Click "✨ Get Help"**
   - The AI will analyze your question
   - You'll get a thoughtful, educational response

4. **Review the Response**
   - Read through the explanation
   - Click links or examples to understand better

### Saving Responses

1. **Click "☆ Save"** button on any response
   - The button will change to "⭐ Saved"
   - This bookmark saves the response for later

2. **Access saved responses** in the "History" tab
   - Click "⭐ Saved" filter
   - View only your bookmarked responses

### Viewing History

1. **Click "📚 History" tab**
   - See all your past questions and responses
   - Click any item to view it again
   - Shows date and time of each interaction

2. **Filter options:**
   - **All** - View all questions and responses
   - **⭐ Saved** - View only bookmarked items

3. **Delete responses**
   - Click 🗑️ button on any response
   - Confirm deletion
   - Response is removed from history

## Tips for Better Help

### 📝 Ask Detailed Questions

**Good:** "I don't understand how to solve quadratic equations using the quadratic formula. Can you explain the steps and why we use this method?"

**Not as helpful:** "Explain quadratic equations"

### 🎯 Provide Context

Include:
- What you've already tried
- What you understand so far
- What specific part is confusing
- The level of explanation you need (high school, college, etc.)

### 🤔 Ask About the "Why"

Instead of asking for direct answers, ask:
- "Why does this work?"
- "Can you explain the concept behind this?"
- "What's an example of when we'd use this?"
- "How does this connect to what we learned before?"

### 📚 Link to Subjects

When you select a subject:
- Homework helper understands context better
- You can filter history by subject
- Easier to find related responses later

### 💾 Save Important Responses

Save responses that:
- Explain key concepts you struggle with
- Break down complex topics well
- Include useful examples
- You want to review before tests

## Example Questions

### Math
- "Can you explain how to find the derivative of x³ + 2x using the power rule?"
- "I'm confused about the difference between permutations and combinations. Can you give examples?"
- "How do I solve systems of equations using substitution? Walk me through the steps."

### Science
- "What's the difference between mitosis and meiosis? Why do cells need both?"
- "Can you explain photosynthesis step-by-step? I don't understand the light-dependent reactions."
- "How does Newton's second law (F=ma) relate to the motion of objects?"

### Languages
- "When do I use the subjunctive mood in Spanish? Give me examples with translations."
- "What's the difference between the imparfait and passé composé in French?"
- "Can you explain German case endings and why they matter?"

### Literature & English
- "What's the symbolism of the green light in The Great Gatsby?"
- "Explain the difference between similes and metaphors with examples from literature."
- "How do authors use foreshadowing? Give examples from books we might read."

### History
- "What caused the fall of the Roman Empire? Explain the major factors."
- "Can you compare the causes of World War 1 and World War 2?"
- "Explain the main ideas of the Enlightenment philosophers."

## API Details

### Endpoints

**Ask a Question**
```
POST /api/homework-help/ask
Body: {
  title: string,           // Brief title
  question: string,        // Your question
  subjectId?: string       // Optional: subject ID
}
```

**Get History**
```
GET /api/homework-help/history?saved=true&subjectId=1
```

**Update Response**
```
PUT /api/homework-help/[id]
Body: { saved: boolean, helpful: boolean }
```

**Delete Response**
```
DELETE /api/homework-help/[id]
```

## Pricing & Limits

### Anthropic API Pricing
- **Free Trial**: $5 in free credits for new accounts
- **Pay-as-you-go**: Approximately $0.003 per 1K input tokens, $0.015 per 1K output tokens
- **Current Model**: Claude 3.5 Sonnet (most capable, cost-effective)

### Expected Costs
- Average homework question: ~$0.01-0.03 per response
- Save money by asking detailed questions (fewer follow-ups needed)
- 100 questions: approximately $1-3 in API costs

### Managing Usage
- Track your API usage at [console.anthropic.com](https://console.anthropic.com)
- Set usage limits in your account settings
- Consider your usage rate to budget costs

## Best Practices

### ✅ Do This
- Be specific and detailed
- Ask about concepts you don't understand
- Save responses for difficult topics
- Use it to supplement your learning
- Ask follow-up questions for clarity
- Link to relevant subjects
- Review saved responses before tests

### ❌ Avoid This
- Don't ask for direct homework answers
- Don't ask it to do your assignment for you
- Don't ask overly broad questions
- Don't ignore the responses without thinking
- Don't rely solely on homework helper (use textbooks too)
- Don't ask questions you should research in class materials first

## Troubleshooting

### "API service not configured" Error
**Solution**: 
- Make sure you have `ANTHROPIC_API_KEY` in `.env.local`
- Restart development server after adding the key
- Check that the key is valid at [console.anthropic.com](https://console.anthropic.com)

### Questions Take Too Long
**Solutions**:
- This is normal - AI responses take a few seconds
- Complex questions may take longer
- Check your internet connection

### Can't Save Responses
**Solutions**:
- Make sure you're signed in
- Verify the response loaded completely
- Try refreshing the page

### History Not Showing
**Solutions**:
- Refresh the page
- Make sure you're in the right tab
- Check if filters are hiding responses

### Getting Generic Responses
**Solutions**:
- Add more context and detail to questions
- Ask about specific concepts
- Include what you've already tried
- Ask for step-by-step explanations

## Advanced Tips

### Study Strategy Integration
1. **Before studying**: Ask to explain the topic overview
2. **While studying**: Ask about specific confusing parts
3. **After studying**: Ask questions to test your understanding
4. **Before exams**: Review saved responses on difficult topics

### Different Question Types

**Concept Questions**: "What is X and how does it work?"
- Gets clear explanation of fundamentals

**Problem-Solving**: "How would I approach solving X?"
- Gets methodology and thinking process

**Connection Questions**: "How does X relate to Y?"
- Builds understanding of connections

**Application Questions**: "Where would we use X in real life?"
- Deepens understanding with context

### Organizing Saved Responses
- Save one response per concept
- Name topics clearly in titles
- Use subject selection for filtering
- Delete duplicate or less helpful responses
- Review before tests

## Learning Tips

The Homework Helper works best as a **learning tool**, not a shortcut:

1. **Read the question first** - Try to solve it before asking
2. **Read responses carefully** - Don't just skim
3. **Work through examples** - Try the examples yourself
4. **Ask follow-ups** - "I still don't understand X" is okay
5. **Apply what you learned** - Use the explanation to solve similar problems

## FAQ

**Q: Will the AI do my homework for me?**
A: No. It's designed to help you understand concepts. Ask about the "why" and methodology, not for direct answers.

**Q: Can I use this during tests?**
A: This is for learning before tests. Using it during exams would be cheating. Use saved responses to study!

**Q: Is my data private?**
A: Your questions and responses are stored in your School Helper database. They're linked to your account only.

**Q: How many questions can I ask?**
A: As many as you want! But remember each response costs a small amount. Budget accordingly.

**Q: Can it help with any subject?**
A: Yes! Math, science, languages, history, literature, computer science, and more. It's trained on diverse knowledge.

**Q: What if the answer is wrong?**
A: AI makes mistakes sometimes. Always verify important information with your textbook or teacher. It's a learning aid, not a primary source.

**Q: Can I edit my saved responses?**
A: Not yet, but you can delete and re-ask questions for different explanations.

**Q: How long does a response take?**
A: Usually 5-30 seconds depending on question complexity and internet speed.

## Integration with School Helper

The Homework Helper integrates with other features:

- **Link to Subjects**: Select subjects when asking questions
- **Track in Dashboard**: See your homework helper usage
- **Save for Study Notes**: Important responses can be converted to study notes manually

## Getting More Help

### Resources
- **Textbooks** - Primary source for learning
- **Class Notes** - Reference your teacher's explanations
- **Study Groups** - Learn from classmates
- **Teacher Office Hours** - Get help directly from experts
- **School Tutoring** - Professional academic support
- **Homework Helper** - Additional perspective and explanation

## Pro Tips

1. **Copy-paste examples**: You can save text from responses for study notes
2. **Multiple questions**: Ask the same concept in different ways for different perspectives
3. **Build your library**: Over time you'll have a collection of saved responses on key topics
4. **Use before asking teacher**: Try homework helper first, then ask teacher for clarification
5. **Combine with notes**: Pair homework helper responses with your class notes

---

**Remember**: Homework Helper is here to help you *learn*, not to do the work *for* you. The best learning happens when you engage with the material and understand the "why" behind concepts.

Happy learning! 📚✨
