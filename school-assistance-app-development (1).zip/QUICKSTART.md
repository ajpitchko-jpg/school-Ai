# 🚀 School Helper - Quick Start (5 Minutes)

## Installation

### Step 1: Install Docker (If not already installed)

Download and install **Docker Desktop** from:
https://www.docker.com/products/docker-desktop

### Step 2: Run One Command

#### On Mac/Linux:
```bash
chmod +x setup.sh && ./setup.sh
```

#### On Windows:
```bash
setup.bat
```

That's it! Wait 2-3 minutes for setup to complete.

### Step 3: Open Your Browser

Go to:
```
http://localhost:3000
```

**Done!** 🎉 School Helper is running!

---

## Using School Helper

### First Time
1. Click "Use as guest" to try the app immediately
2. Add your subjects, assignments, and grades
3. No account or API keys needed!

### Enable Google Classroom (Optional)

1. Open `.env.local` with a text editor
2. Get credentials from: https://console.cloud.google.com
3. Add your `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`
4. Run: `docker-compose restart app`
5. Now you can sign in with Google!

### Enable Homework Helper (Optional)

1. Open `.env.local`
2. Get API key from: https://console.anthropic.com
3. Add your `ANTHROPIC_API_KEY`
4. Run: `docker-compose restart app`
5. Click "🤖 Helper" to use AI homework help!

### Enable Reading Helper Audio (Optional)

1. Open `.env.local`
2. Get API key from: https://platform.openai.com
3. Add your `OPENAI_API_KEY`
4. Run: `docker-compose restart app`
5. Click "📚 Reading" and get book summaries with audio!

---

## Stop the App

```bash
docker-compose down
```

Your data is saved and will be there when you start it again!

---

## Quick Troubleshooting

| Problem | Solution |
|---------|----------|
| App won't start | Run `docker-compose logs -f app` to see errors |
| Can't access http://localhost:3000 | Wait 30 seconds for app to boot, or check if another app uses port 3000 |
| Database error | Run `docker-compose restart database` then `docker-compose restart app` |
| Port 3000 in use | Edit `docker-compose.yml` change `3000:3000` to `8000:3000` |

For more help, see `DOCKER_SETUP.md` and `COMPLETE_SETUP_GUIDE.md`.

---

## What You Get

✅ **Dashboard** - Overview of your academic life
✅ **Subjects** - Manage your courses
✅ **Assignments** - Track what's due
✅ **Grades** - Monitor your performance
✅ **Notes** - Study materials
✅ **Schedule** - Plan your time
✅ **Homework Helper** - AI answers questions (optional)
✅ **Reading Helper** - AI summarizes books (optional)

---

## Features Comparison

| Feature | Always Available | Optional (needs API key) |
|---------|-----------------|------------------------|
| Dashboard | ✅ | |
| Subjects | ✅ | |
| Assignments | ✅ | |
| Grades | ✅ | |
| Notes | ✅ | |
| Schedule | ✅ | |
| Google Classroom | | ✅ Google Cloud |
| Homework Helper | | ✅ Anthropic |
| Reading Helper | ✅ (text only) | ✅ OpenAI (for audio) |

---

## Commands Cheat Sheet

```bash
# Start the app
docker-compose up -d

# Stop the app
docker-compose down

# View logs
docker-compose logs -f app

# Restart the app
docker-compose restart app

# Check if running
docker-compose ps

# Get shell access
docker-compose exec app /bin/sh
```

---

## File Structure

```
.
├── setup.sh                 # Mac/Linux setup script
├── setup.bat               # Windows setup script
├── docker-compose.yml      # Docker configuration
├── Dockerfile              # Container definition
├── .env.local             # Your configuration (created automatically)
├── DOCKER_SETUP.md        # Detailed Docker guide
├── COMPLETE_SETUP_GUIDE.md # Full documentation
└── (source code files)
```

---

## Next Steps

1. ✅ Run setup.sh or setup.bat
2. ✅ Open http://localhost:3000
3. ✅ Start using School Helper!
4. ✅ (Optional) Add API keys for advanced features

---

## Support

- **Docker issues?** → See `DOCKER_SETUP.md`
- **Features help?** → See `COMPLETE_SETUP_GUIDE.md`
- **Homework Helper?** → See `HOMEWORK_HELPER_GUIDE.md`
- **Reading Helper?** → See `READING_HELPER_GUIDE.md`

---

**That's it! Happy studying!** 📚✨

Questions? The answers are in the documentation files included with your download.
