# Google Classroom Integration Setup Guide

This guide will help you set up Google Classroom integration with School Helper.

## Step 1: Create a Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Click on the project dropdown and select "NEW PROJECT"
3. Enter a project name (e.g., "School Helper")
4. Click CREATE

## Step 2: Enable Required APIs

1. In the Google Cloud Console, go to "APIs & Services" > "Library"
2. Search for and enable these APIs:
   - **Google Classroom API**
   - **Google+ API**

3. For each API:
   - Click on the API
   - Click "Enable"

## Step 3: Create OAuth 2.0 Credentials

1. Go to "APIs & Services" > "Credentials"
2. Click "Create Credentials" > "OAuth 2.0 Client ID"
3. If prompted, configure the OAuth consent screen first:
   - Choose "External" user type
   - Fill in required information:
     - App name: "School Helper"
     - User support email: your email
     - Developer contact: your email
   - Add scopes:
     - `classroom.courses`
     - `classroom.coursework.me`
     - `classroom.announcements`
     - `userinfo.email`
     - `userinfo.profile`
   - Add test users if in development

4. Back to OAuth 2.0 Client ID creation:
   - Application type: **Web application**
   - Name: "School Helper"
   - Authorized redirect URIs:
     - `http://localhost:3000/api/auth/callback/google` (for development)
     - `https://yourdomain.com/api/auth/callback/google` (for production)

5. Click CREATE
6. Copy the Client ID and Client Secret

## Step 4: Configure Environment Variables

1. Open `.env.local` in your project root
2. Add the following:

```env
GOOGLE_CLIENT_ID=your_copied_client_id
GOOGLE_CLIENT_SECRET=your_copied_client_secret
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your_secret_key_here
```

To generate a NEXTAUTH_SECRET, run:
```bash
npx auth secret
```

## Step 5: How to Use

1. **Sign In**: Click "Sign in with Google" on the login page
2. **Grant Permissions**: Allow the app to access your Google Classroom data
3. **Sync Courses**: Click "🔗 Sync Now" on the dashboard
4. The app will automatically:
   - Import all your courses as subjects
   - Fetch assignments from each course
   - Keep everything up to date

## Features Available After Sync

✅ **Auto-imported Courses**: Your Google Classroom courses appear as subjects
✅ **Auto-imported Assignments**: Course assignments are synced automatically
✅ **Two-way Tracking**: Track completion in School Helper
✅ **Regular Sync**: Sync again anytime to get the latest updates

## Troubleshooting

### "No access token" error
- Sign out and sign in again
- Make sure you've granted the necessary permissions

### Courses not syncing
- Check that the Google Cloud project has the Classroom API enabled
- Verify your OAuth credentials are correct
- Try signing out and signing back in

### Missing assignments
- Make sure teachers have assigned work in Google Classroom
- Try syncing again with the "🔗 Sync Now" button

## Production Deployment

When deploying to production:

1. Add your production domain to authorized redirect URIs:
   - `https://yourdomain.com/api/auth/callback/google`

2. Update NEXTAUTH_URL:
   ```env
   NEXTAUTH_URL=https://yourdomain.com
   ```

3. Generate a new NEXTAUTH_SECRET:
   ```bash
   npx auth secret
   ```

4. Update Google Cloud OAuth consent screen:
   - Change from "External" to "Internal" if your organization allows
   - Add your production domain

## FAQ

**Q: Can I use the app without Google Classroom?**
A: Yes! You can use "Sign in as guest" to use the app without Google integration.

**Q: How often should I sync?**
A: Sync whenever teachers post new assignments or make changes. You can sync as many times as you want.

**Q: Is my data secure?**
A: Yes! We only request read access to your courses and assignments. We never modify your Google Classroom data. Your data is stored securely in our database.

**Q: What if I revoke Google permissions?**
A: You can revoke access in Google Account Settings. The app will ask for permission again on next login.
