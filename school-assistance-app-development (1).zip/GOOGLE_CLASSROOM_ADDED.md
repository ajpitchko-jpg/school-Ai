# Google Classroom Integration - What Was Added

This document outlines the new Google Classroom integration features added to School Helper.

## New Database Tables

### Users Table
Stores user information and Google OAuth tokens:
- `id` - Primary key
- `email` - User email (unique)
- `name` - User display name
- `googleId` - Google user ID
- `googleAccessToken` - OAuth access token for API calls
- `googleRefreshToken` - Refresh token for long-lived sessions
- `googleTokenExpiry` - When the access token expires
- `createdAt`, `updatedAt` - Timestamps

### Updated Subjects Table
Added Google Classroom fields:
- `userId` - Link to user who owns the subject
- `googleClassroomId` - ID of the course in Google Classroom
- `googleClassroomData` - Full course data stored as JSON

### Updated Assignments Table
Added Google Classroom fields:
- `googleClassroomWorkId` - ID of the work item in Google Classroom
- `googleClassroomData` - Full assignment data stored as JSON

## New Authentication System

### NextAuth.js Integration
- Implemented with Google OAuth 2.0 provider
- JWT-based session management
- Secure token storage in database

### New Files
- `src/lib/auth.ts` - NextAuth configuration with Google provider and callbacks
- `src/types/next-auth.d.ts` - TypeScript type definitions for extended session
- `src/app/api/auth/route.ts` - Auth handler route
- `src/app/api/auth/signin/route.ts` - Sign-in endpoint
- `src/app/api/auth/signout/route.ts` - Sign-out endpoint
- `src/app/login/page.tsx` - Login page with Google sign-in button
- `src/components/Providers.tsx` - SessionProvider wrapper for client-side auth
- `src/components/UserMenu.tsx` - User profile menu with sign-out

## New API Endpoint

### POST /api/classroom/sync
Synchronizes Google Classroom data with the School Helper database.

**Functionality:**
1. Authenticates with Google Classroom API
2. Fetches all courses the user is enrolled in
3. For each course:
   - Creates or updates a subject in the database
   - Fetches all coursework (assignments)
   - Imports or updates assignments

**Response:**
```json
{
  "success": true,
  "message": "Synced X courses from Google Classroom",
  "subjects": [
    { "id": 1, "name": "Math 101", "code": "MATH101" }
  ]
}
```

## New Components

### GoogleClassroomSync Component
(`src/components/GoogleClassroomSync.tsx`)
- "🔗 Sync Now" button on the dashboard
- Shows sync status and messages
- Handles loading and error states
- Auto-refreshes page on successful sync

### UserMenu Component
(`src/components/UserMenu.tsx`)
- Displays user profile with avatar
- Shows user name and email
- Sign-out functionality
- Dropdown menu for easy access

## Updated Pages

### Login Page (`src/app/login/page.tsx`)
- Beautiful login screen
- Google sign-in button with branding
- Feature list highlighting Google Classroom integration
- Guest sign-in option to use without Google

### Dashboard (`src/app/page.tsx`)
- Added SessionProvider integration
- Google Classroom sync button on dashboard
- Displays user info when authenticated

### Main Layout (`src/app/layout.tsx`)
- SessionProvider setup for authentication
- User menu in navigation when authenticated
- Sign-in link when not authenticated

## Configuration Files

### Environment Variables
New required variables:
```env
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your_secret_key_here
```

### .env.example
Added example configuration file for easy setup

## Permissions & Scopes

The app requests the following Google scopes:
- `openid` - Basic user identification
- `profile` - User profile information
- `email` - User email address
- `classroom.courses` - View user's classes
- `classroom.coursework.me` - View assignments for user
- `classroom.announcements` - View class announcements (prepared for future use)

**Important**: The app only requests READ permissions. It never modifies Google Classroom data.

## Security Features

1. **Token Storage**: OAuth tokens are securely stored in PostgreSQL
2. **JWT Sessions**: Session data is signed and verified
3. **No Hardcoded Secrets**: All secrets come from environment variables
4. **HTTPS Required**: NEXTAUTH_URL must be HTTPS in production
5. **Scope Limitation**: Only necessary permissions are requested
6. **No Classroom Modifications**: The app never writes to Google Classroom

## User Flow

1. User visits app → Redirected to login page
2. User clicks "Sign in with Google"
3. Google OAuth flow completes
4. User data and tokens stored in database
5. User redirected to dashboard
6. User clicks "🔗 Sync Now" button
7. App fetches courses and assignments from Google Classroom
8. Subjects and assignments created/updated in database
9. User can manage everything in School Helper

## Data Sync

### Initial Sync
When user clicks "Sync Now" for the first time:
- All courses are imported as subjects
- All course assignments are imported
- Data is stored in the database

### Subsequent Syncs
On later syncs:
- Existing subjects/assignments are updated
- New courses/assignments are added
- Completed work status is preserved

### Manual Tracking
- User can still manually add subjects and assignments
- User-created items don't get overwritten by syncs
- Full flexibility to customize

## Database Migrations

Three main changes to the schema:
1. New `users` table for authentication
2. Updated `subjects` table with Google Classroom fields
3. Updated `assignments` table with Google Classroom fields

All changes are backward compatible. Existing data remains intact.

## Setup Instructions

Complete setup instructions are in: `GOOGLE_CLASSROOM_SETUP.md`

Quick version:
1. Create Google Cloud Project
2. Enable Classroom API
3. Create OAuth 2.0 credentials
4. Add credentials to `.env.local`
5. Run `npm run dev`
6. Click "Sign in with Google"
7. Click "🔗 Sync Now" on dashboard

## Next Steps / Future Enhancements

Possible future features:
- [ ] Sync classroom announcements to dashboard
- [ ] View student submissions in School Helper
- [ ] Calendar view showing all events and due dates
- [ ] Export grades to PDF
- [ ] Mobile app version
- [ ] Notification for upcoming deadlines
- [ ] Collaboration features
- [ ] Progress reports and analytics

## Testing Google Classroom Integration

To test the integration:
1. Create a test Google Cloud project
2. Add real Google Classroom courses
3. Create coursework in those courses
4. Sign in to School Helper
5. Click "🔗 Sync Now"
6. Verify courses and assignments appear

## Troubleshooting

See `GOOGLE_CLASSROOM_SETUP.md` for common issues and solutions.

## Files Modified/Added

### New Files
- `src/lib/auth.ts`
- `src/types/next-auth.d.ts`
- `src/app/api/auth/route.ts`
- `src/app/api/auth/signin/route.ts`
- `src/app/api/auth/signout/route.ts`
- `src/app/api/classroom/sync/route.ts`
- `src/app/login/page.tsx`
- `src/components/UserMenu.tsx`
- `src/components/Providers.tsx`
- `src/components/GoogleClassroomSync.tsx`
- `.env.example`
- `GOOGLE_CLASSROOM_SETUP.md`
- `GOOGLE_CLASSROOM_ADDED.md` (this file)
- `README.md`

### Modified Files
- `src/db/schema.ts` - Added users, updated subjects and assignments
- `src/app/page.tsx` - Added GoogleClassroomSync component
- `src/app/layout.tsx` - Added SessionProvider and UserMenu
- `package.json` - Added next-auth dependencies

## Support

For issues with Google Classroom integration:
1. Check `GOOGLE_CLASSROOM_SETUP.md`
2. Verify Google Cloud credentials
3. Ensure APIs are enabled
4. Check browser console for errors
5. Verify database is running

---

**Your School Helper now has full Google Classroom integration!** 🎓🔗
