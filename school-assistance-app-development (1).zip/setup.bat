@echo off
REM School Helper - Setup Script (Windows)
REM This script sets up and runs School Helper with Docker

setlocal enabledelayedexpansion

echo.
echo ╔════════════════════════════════════════════════════════════════════╗
echo ║                    📚 SCHOOL HELPER SETUP                          ║
echo ║                                                                    ║
echo ║         Your AI-powered academic companion - One file setup        ║
echo ╚════════════════════════════════════════════════════════════════════╝
echo.

REM Check if Docker is installed
docker --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Docker is not installed!
    echo.
    echo Please install Docker Desktop from: https://www.docker.com/products/docker-desktop
    echo.
    pause
    exit /b 1
)

echo ✅ Docker is installed
echo.

echo 📝 Setting up environment variables...
echo.

REM Create .env.local if it doesn't exist
if not exist ".env.local" (
    (
        echo # Database (auto-configured with Docker^)
        echo DATABASE_URL=postgresql://postgres:postgres@database:5432/app_db
        echo.
        echo # NextAuth Configuration
        echo NEXTAUTH_URL=http://localhost:3000
        echo NEXTAUTH_SECRET=school-helper-secret-key-change-in-production
        echo.
        echo # Google Classroom (Optional - Leave empty to skip^)
        echo GOOGLE_CLIENT_ID=
        echo GOOGLE_CLIENT_SECRET=
        echo.
        echo # Anthropic API (Optional - For Homework Helper^)
        echo ANTHROPIC_API_KEY=
        echo.
        echo # OpenAI API (Optional - For Reading Helper Audio^)
        echo OPENAI_API_KEY=
    ) > .env.local
    
    echo ✅ Created .env.local
    echo.
    echo 📋 To enable features, edit .env.local and add your API keys:
    echo    • Google Classroom: https://console.cloud.google.com
    echo    • Homework Helper: https://console.anthropic.com
    echo    • Reading Helper Audio: https://platform.openai.com
    echo.
    pause
) else (
    echo ✅ .env.local already exists
)

echo.
echo 🐳 Building Docker images...
echo.

docker-compose build --pull
if errorlevel 1 (
    echo.
    echo ❌ Failed to build Docker images
    pause
    exit /b 1
)

echo.
echo 🚀 Starting School Helper...
echo.

docker-compose up -d
if errorlevel 1 (
    echo.
    echo ❌ Failed to start Docker containers
    pause
    exit /b 1
)

echo.
echo ⏳ Waiting for database to be ready...
timeout /t 10

echo.
echo 🗄️  Initializing database...

docker-compose exec -T app npm run db:init >nul 2>&1

echo.
echo ╔════════════════════════════════════════════════════════════════════╗
echo ║                   ✅ SETUP COMPLETE!                              ║
echo ╚════════════════════════════════════════════════════════════════════╝
echo.
echo 📚 School Helper is now running!
echo.
echo 🌐 Open your browser and go to: http://localhost:3000
echo.
echo 📊 Features:
echo    ✓ Academic Management (Subjects, Assignments, Grades, Notes, Schedule^)
echo    ✓ Google Classroom Integration (Optional^)
echo    ✓ Homework Helper with AI (Optional^)
echo    ✓ Reading Helper with Audio (Optional^)
echo.
echo ⌨️  Useful Commands:
echo    • View logs:     docker-compose logs -f app
echo    • Stop app:      docker-compose down
echo    • Restart app:   docker-compose restart app
echo    • Shell access:  docker-compose exec app /bin/sh
echo.
echo 💾 Your data is saved in PostgreSQL and persists between restarts
echo.
echo 📖 Documentation: See README.md and COMPLETE_SETUP_GUIDE.md
echo.
pause
