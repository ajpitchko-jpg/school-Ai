# 📚 School Helper - Your Academic Companion

A full-stack web application designed to help students manage their academic life efficiently. Track assignments, grades, study notes, and schedule all in one place. **Now with Google Classroom integration!**

## Features

### Core Features
✅ **Dashboard** - Overview of your academic progress
✅ **Subjects Management** - Organize your courses
✅ **Assignments** - Track assignments with due dates and priorities
✅ **Grades** - Record and analyze your grades with statistics
✅ **Study Notes** - Keep important study materials organized
✅ **Schedule** - Plan your academic calendar with classes and exams
✅ **Authentication** - Secure login with Google OAuth
✅ **🤖 Homework Helper** - AI-powered homework assistance with Claude AI

### Google Classroom Integration
✅ **Auto-sync Courses** - Import all your Google Classroom courses
✅ **Auto-sync Assignments** - Fetch assignments from Google Classroom automatically
✅ **Two-way Tracking** - Track completion in School Helper while viewing in Google Classroom
✅ **Regular Sync** - Update anytime with the sync button

### Homework Helper (AI-Powered)
✅ **Smart Homework Assistance** - Ask questions, get intelligent explanations
✅ **Multi-Subject Support** - Help with Math, Science, Languages, History, and more
✅ **Save Responses** - Bookmark important explanations with ⭐
✅ **Full History** - Access all past questions and responses
✅ **Subject Linking** - Organize help by your courses
✅ **Learning-Focused** - Designed to help you understand, not just get answers

## Tech Stack

- **Frontend**: Next.js 16 (App Router), React 19, Tailwind CSS
- **Backend**: Next.js API Routes
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: NextAuth.js with Google OAuth
- **Styling**: Tailwind CSS (responsive design)

## Quick Start

### Prerequisites
- Node.js 18+ and npm
- PostgreSQL database
- Google Cloud Project (for Google Classroom integration)

### Installation

1. **Clone and install dependencies**
```bash
npm install
```

2. **Set up environment variables**
```bash
cp .env.example .env.local
```

Edit `.env.local` with your values:
```env
DATABASE_URL=postgresql://user:password@localhost:5432/app_db
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your_secret_key
```

To generate `NEXTAUTH_SECRET`:
```bash
npx auth secret
```

3. **Initialize the database**
```bash
npx drizzle-kit push
```

4. **Run the development server**
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Using the App

### Without Google Classroom
1. Visit the homepage
2. Click "Use as guest" to skip authentication
3. Start adding subjects, assignments, grades, and notes manually

### With Google Classroom
1. See [GOOGLE_CLASSROOM_SETUP.md](./GOOGLE_CLASSROOM_SETUP.md) for detailed setup instructions
2. Get Google OAuth credentials from Google Cloud Console
3. Sign in with your Google account
4. Click "🔗 Sync Now" on the dashboard
5. All your courses and assignments will be imported automatically

## Project Structure

```
src/
├── app/
│   ├── api/                      # API routes (subjects, assignments, etc.)
│   ├── layout.tsx                # Main layout with navigation
│   ├── page.tsx                  # Dashboard
│   ├── login/                    # Login page
│   ├── subjects/                 # Subjects management
│   ├── assignments/              # Assignments tracking
│   ├── grades/                   # Grades management
│   ├── notes/                    # Study notes
│   ├── schedule/                 # Academic calendar
│   └── homework-helper/          # AI homework assistant
├── components/                   # Reusable React components
├── db/                           # Database configuration and schema
├── lib/                          # Utility functions and NextAuth config
└── types/                        # TypeScript type definitions
```

## Database Schema

### Users
- id, email, name
- googleId, googleAccessToken, googleRefreshToken, googleTokenExpiry

### Subjects
- id, name, code, teacher, room
- userId, googleClassroomId, googleClassroomData

### Assignments
- id, title, description, dueDate, status, priority
- subjectId, googleClassroomWorkId, googleClassroomData

### Grades
- id, title, score, maxScore, gradeDate, weight, notes
- subjectId, assignmentId

### Notes
- id, title, content, isImportant
- subjectId, createdAt, updatedAt

### Schedule
- id, title, type, date, startTime, endTime, location, notes
- subjectId

## API Endpoints

### Subjects
- `GET /api/subjects` - Get all subjects
- `POST /api/subjects` - Create subject
- `GET /api/subjects/[id]` - Get subject
- `PUT /api/subjects/[id]` - Update subject
- `DELETE /api/subjects/[id]` - Delete subject

### Assignments
- `GET /api/assignments` - Get all assignments (with filters)
- `POST /api/assignments` - Create assignment
- `GET /api/assignments/[id]` - Get assignment
- `PUT /api/assignments/[id]` - Update assignment
- `DELETE /api/assignments/[id]` - Delete assignment

### Grades
- `GET /api/grades` - Get all grades
- `POST /api/grades` - Create grade
- `GET /api/grades/[id]` - Get grade
- `PUT /api/grades/[id]` - Update grade
- `DELETE /api/grades/[id]` - Delete grade

### Notes
- `GET /api/notes` - Get all notes
- `POST /api/notes` - Create note
- `GET /api/notes/[id]` - Get note
- `PUT /api/notes/[id]` - Update note
- `DELETE /api/notes/[id]` - Delete note

### Schedule
- `GET /api/schedule` - Get all schedule items
- `POST /api/schedule` - Create schedule item
- `GET /api/schedule/[id]` - Get schedule item
- `PUT /api/schedule/[id]` - Update schedule item
- `DELETE /api/schedule/[id]` - Delete schedule item

### Classroom Integration
- `POST /api/classroom/sync` - Sync Google Classroom courses and assignments

## Production Deployment

### Environment Setup
```bash
export DATABASE_URL="postgresql://..."
export GOOGLE_CLIENT_ID="..."
export GOOGLE_CLIENT_SECRET="..."
export NEXTAUTH_URL="https://yourdomain.com"
export NEXTAUTH_SECRET="..."  # Use npx auth secret to generate
```

### Build and Deploy
```bash
npm run build
npm run start
```

### Google OAuth Redirect URIs
Make sure to add your production domain to Google Cloud Console:
- `https://yourdomain.com/api/auth/callback/google`

## Features & Usage

### Dashboard
- View overall statistics (subjects, pending assignments, average grade)
- See upcoming assignments with urgency indicators
- Quick access to all features

### Subjects
- Add, edit, and delete subjects
- Track teacher info and classroom location
- View subject-specific performance

### Assignments
- Create assignments with due dates and priorities
- Filter by status (Pending, Completed, Overdue)
- Mark assignments as complete
- Visual priority indicators

### Grades
- Record grades with scores and max scores
- Automatic percentage calculation
- View subject-specific averages
- Overall GPA tracking

### Notes
- Create and organize study notes
- Mark important notes with ⭐
- Filter by subject
- Support for formatted text

### Schedule
- Add classes, exams, labs, and other events
- Schedule with specific times and locations
- Group by date for easy viewing
- Type indicators with emojis

### Homework Helper
- Ask homework questions about any subject
- Get AI-powered explanations from Claude
- Link questions to your courses
- Save important responses
- View complete history of interactions
- Beautiful markdown-formatted responses

## Troubleshooting

### Database Connection Issues
- Ensure PostgreSQL is running
- Verify DATABASE_URL is correct
- Check database exists and is accessible

### Google Classroom Sync Not Working
- Verify Google credentials are correct
- Check that Google Classroom API is enabled
- Ensure you've granted necessary permissions
- See [GOOGLE_CLASSROOM_SETUP.md](./GOOGLE_CLASSROOM_SETUP.md)

### Homework Helper Not Working
- Check that ANTHROPIC_API_KEY is set in .env.local
- Verify API key is valid at [console.anthropic.com](https://console.anthropic.com)
- Ensure you have credits or free trial available
- See [HOMEWORK_HELPER_GUIDE.md](./HOMEWORK_HELPER_GUIDE.md)

### Build Errors
```bash
# Clear cache and rebuild
rm -rf .next
npm run build
```

## Contributing

Contributions are welcome! Feel free to:
- Report bugs
- Suggest features
- Submit pull requests

## License

MIT License - feel free to use this project for personal or educational purposes.

## Support

Need help? Check out:
- [GOOGLE_CLASSROOM_SETUP.md](./GOOGLE_CLASSROOM_SETUP.md) - Detailed Google Classroom setup
- [Next.js Documentation](https://nextjs.org)
- [NextAuth.js Documentation](https://next-auth.js.org)

---

**Happy studying!** 🎓📚
